/***************************************************************************
  This file is part of Project Apollo - NASSP
  Copyright 2004-2005 Mark Grant

  Toggle switch handling code.
  This file defines a number of useful toggle switches which can
  be set up to avoid huge swathes of code checking for mouse events,
  checking and processing switch state, and displaying switch state.

  Project Apollo is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  Project Apollo is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Project Apollo; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  See http://nassp.sourceforge.net/license/ for more details.

  **************************************************************************/

// To force Orbitersdk.h to use <fstream> in any compiler version
#pragma include_alias( <fstream.h>, <fstream> )

#include "toggleswitch.h"

#include "IMU.h"
#include "missiontimer.h"
#include "apolloguidance.h"
#include "ioChannels.h"
#include "powersource.h"
#include "FDAI.h"
#include "scs.h"
#include "connector.h"
#include "checklistController.h"

#include "tracer.h"

//
// Generic panel switch item.
//

PanelSwitchItem::PanelSwitchItem() : fInitialAnimState(0.0)

{
	Failed = false;
	FailedState = 0;
	state = 0;

	name = 0;
	next = 0;
	nextForScenario = 0;

	DisplayName = 0;
	flashing = false;
	visible = true;
	doTimeStep = false;

	callback = 0;

	bHasAnimations = false;
	bHasDirection = false;
	bHasReference = false;
	bHasMeshGroup = false;

	reference = dir = arrowoffset = { 0,0,0 };
}

PanelSwitchItem::~PanelSwitchItem()
{
	if (callback)
		delete callback;
}
void PanelSwitchItem::SetCallback(PanelSwitchCallbackInterface *call)
{
	if (callback)
		delete callback;
	callback = call;
}

char *PanelSwitchItem::GetDisplayName()

{
	if (DisplayName)
		return DisplayName;

	return name;
}

//
// Get the state. If it's failed, return the failed state.
//
// Note that you should always call this to get the state unless you're actually concerned with
// the appearance of the switch rather than the functionality.
//

int PanelSwitchItem::GetState()

{
	if (!Failed)
		return state;

	return FailedState;
}

void PanelSwitchItem::SetState(int value)

{
	state = value;
}

void PanelSwitchItem::DefineVCAnimations(UINT vc_idx)
{
}

bool PanelSwitchItem::VerifyAnimations()
{
	bHasAnimations = true;
	return true;
}

void PanelSwitchItem::SetReference(const VECTOR3& ref)
{
	bHasReference = true;
	reference = ref;
}

void PanelSwitchItem::SetDirection(const VECTOR3& _dir)
{
	bHasDirection = true;
	dir = _dir;
}

void PanelSwitchItem::SetArrowOffset(const VECTOR3 & _off)
{
	arrowoffset = _off;
}

void PanelSwitchItem::SetReference(const VECTOR3& ref, const VECTOR3& dir)
{
	bHasReference = true;
	bHasDirection = true;
	reference = ref;
	this->dir = dir;
}

void PanelSwitchItem::SetInitialAnimState(double fState)
{
	fInitialAnimState = fState;
}

const VECTOR3& PanelSwitchItem::GetReference() const
{
	return reference;
}

VECTOR3 PanelSwitchItem::GetChecklistReference() const
{
	return (reference + arrowoffset);
}

const VECTOR3& PanelSwitchItem::GetDirection() const
{
	return dir;
}

//
// Generic toggle switch.
//

TwoPositionSwitch::TwoPositionSwitch() {

	x = 0;
	y = 0;
	width = 0;
	height = 0;
	springLoaded = SPRINGLOADEDSWITCH_NONE;

	next = 0;

	SwitchSurface = 0;
	BorderSurface = 0;

	OurVessel = 0;
	switchRow = 0;

	Active = true;
	Held = false;
	Sideways = 0;
	delayTime = 0;
	resetTime = 0;

	anim_switch = NULL;
	grpIndex = 0;
}

TwoPositionSwitch::~TwoPositionSwitch() {
}

void TwoPositionSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, int springloaded, char *dname) {

	name = n;
	state = defaultState;
	springLoaded = springloaded;
	scnh.RegisterSwitch(this);

	DisplayName = dname;
}

void TwoPositionSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, int xoffset, int yoffset)

{
	x = xp;
	y = yp;
	width = w;
	height = h;
	xOffset = xoffset;
	yOffset = yoffset;
	SwitchSurface = surf;
	BorderSurface = bsurf;
	
	SwitchToggled = false;
	
	row.AddSwitch(this);
	switchRow = &row;
	OurVessel = switchRow->panelSwitches->vessel;

	InitSound(switchRow->panelSwitches->soundlib);
}

void TwoPositionSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SoundLib &s, int xoffset, int yoffset) {

	x = xp;
	y = yp;
	width = w;
	height = h;
	xOffset = xoffset;
	yOffset = yoffset;
	SwitchSurface = surf;

	InitSound(&s);
}

void TwoPositionSwitch::InitSound(SoundLib *s) {

	if (!Sclick.isValid())
		s->LoadSound(Sclick, CLICK_SOUND, INTERNAL_ONLY);
}

bool TwoPositionSwitch::SwitchTo(int newState, bool dontspring) {

	if (Active)
	{
		if (state != newState)
		{
			state = newState;
			SwitchToggled = true;
			if (switchRow)
			{
				if (switchRow->panelSwitches->listener) 
					switchRow->panelSwitches->listener->PanelSwitchToggled(this);
			}
			if (callback)
				callback->call(this);

			//
			// Reset the switch if it's spring-loaded and not held.
			//
			if (IsSpringLoaded() && !IsHeld() && !dontspring)
			{
				if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(TOGGLESWITCH_DOWN,true);
				if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(TOGGLESWITCH_UP,true);
			}
			return true;
		}
		if (IsSpringLoaded() && !IsHeld() && !dontspring)
		{
			if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   return SwitchTo(TOGGLESWITCH_DOWN,true);
			if (springLoaded == SPRINGLOADEDSWITCH_UP)     return SwitchTo(TOGGLESWITCH_UP,true);
		}
	}
	return false;
}

unsigned int TwoPositionSwitch::GetFlags()

{
	ToggleSwitchFlags fs;

	fs.Held = Held ? 1 : 0;

	return fs.flags;
}

void TwoPositionSwitch::SetFlags(unsigned int f)

{
	ToggleSwitchFlags fs;

	fs.flags = f;

	Held = (fs.Held != 0);
}

bool TwoPositionSwitch::DoCheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	//
	// Check whether it's actually in our switch region.
	//

	if (mx < x || my < y)
		return false;

	if (mx > (x + width) || my > (y + height))
		return false;

	///
	/// \todo Get CTRL state properly if and when Orbiter supports it.
	///
	SHORT ctrlState = GetKeyState(VK_SHIFT);

	if (IsSpringLoaded())
		SetHeld((ctrlState & 0x8000) != 0);

	//
	// Yes, so now we just need to check whether it's an on or
	// off click.
	//

	if (event & PANEL_MOUSE_LBDOWN) {
		if ((!Sideways && my > (y + (height / 2.0))) || (Sideways && mx < (x + (width / 2.0)))) {
			if (state != TOGGLESWITCH_DOWN) {
				SwitchTo(TOGGLESWITCH_DOWN,true);
				Sclick.play();
			}
		}
		else {
			if (state != TOGGLESWITCH_UP) {
				SwitchTo(TOGGLESWITCH_UP,true);
				Sclick.play();
			}
		}
	}
	else if (IsSpringLoaded() && ((event & PANEL_MOUSE_LBUP) != 0) && !IsHeld()) {
		if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(TOGGLESWITCH_DOWN);
		if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(TOGGLESWITCH_UP);
	}
	return true;
}

bool TwoPositionSwitch::CheckMouseClick(int event, int mx, int my) {

	if (visible)
		return DoCheckMouseClick(event, mx, my);
	else
		return false;
}

bool TwoPositionSwitch::DoCheckMouseClickVC(int event, VECTOR3 &p)
{
	int mx, my;

	mx = x + int(p.x * width);
	my = y + int(p.y * height);

	return CheckMouseClick(event, mx, my);
}

bool TwoPositionSwitch::CheckMouseClickVC(int event, VECTOR3 &p)
{
	return DoCheckMouseClickVC(event, p);
}

void TwoPositionSwitch::VesimSwitchTo(int newState)
{
	if (newState != state) {
		SwitchTo(newState, true);
		Sclick.play();
	}
}

void TwoPositionSwitch::DoDrawSwitch(SURFHANDLE DrawSurface)

{
	if (state == TOGGLESWITCH_UP)
	{
		oapiBlt(DrawSurface, SwitchSurface, x, y, xOffset, yOffset, width, height, SURF_PREDEF_CK);
	}
	else
	{
		oapiBlt(DrawSurface, SwitchSurface, x, y, xOffset + width, yOffset, width, height, SURF_PREDEF_CK);
	}
}

void TwoPositionSwitch::DrawSwitch(SURFHANDLE DrawSurface)

{
	if (visible) 
		DoDrawSwitch(DrawSurface);
}

void TwoPositionSwitch::DrawSwitchVC(int id, int event, SURFHANDLE surf)
{
	if (!bHasAnimations) return;

	if (state == TOGGLESWITCH_UP) {
		OurVessel->SetAnimation(anim_switch, 1.0);
	}
	else
	{
		OurVessel->SetAnimation(anim_switch, 0.0);
	}
}

void TwoPositionSwitch::DefineMeshGroup(UINT _grpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
}

//
// Generic function to draw a flashing box around the switch. This is only called if the
// flashing is currently active.
//

void TwoPositionSwitch::DrawFlash(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;

	if (BorderSurface)
		oapiBlt(DrawSurface, BorderSurface, x, y, 0, 0, width, height, SURF_PREDEF_CK);
}

void TwoPositionSwitch::SetActive(bool s) {
	Active = s;
}

void TwoPositionSwitch::SaveState(FILEHANDLE scn)

{
	char buffer[1000];

	sprintf(buffer, "%i %u", state, GetFlags()); 
	oapiWriteScenario_string(scn, name, buffer);
}

void TwoPositionSwitch::LoadState(char *line)
{
	// Load state
	char buffer[100];
	int st = 0;
	unsigned int f = 0;

	sscanf(line, "%s %i %u", buffer, &st, &f);
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
		SetFlags(f);
	}
}

void TwoPositionSwitch::SetState(int value)
{
	if (!delayTime) {
		if (SwitchTo(value))
			Sclick.play();
	} else {
		if (SwitchTo(value, true)) {
			Sclick.play();
			doTimeStep = true;
			resetTime = switchRow->panelSwitches->lastexecutedtime + delayTime;
		}
	}
}

void TwoPositionSwitch::timestep(double missionTime)
{
	if (missionTime <= resetTime)
		return;
	doTimeStep = false;
	SwitchTo(state);
}

//
// Toggle switch
//

ToggleSwitch::ToggleSwitch()
{
	pswitchrot = NULL;
	RotationRange = PI / 4;
}

ToggleSwitch::~ToggleSwitch()
{
	if (pswitchrot)
		delete pswitchrot;
}

void ToggleSwitch::SetRotationRange(const double range)
{
	RotationRange = range;
}

const double ToggleSwitch::GetRotationRange() const
{
	return RotationRange;
}

void ToggleSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), GetDirection(), (float)(GetRotationRange()));
		anim_switch = OurVessel->CreateAnimation(0.5);
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

//
// Three pos switch.
//

bool ThreePosSwitch::CheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	//
	// Check whether it's actually in our switch region.
	//

	if (mx < x || my < y)
		return false;

	if (mx > (x + width) || my > (y + height))
		return false;

	///
	/// \todo Get CTRL state properly if and when Orbiter supports it.
	///
	SHORT ctrlState = GetKeyState(VK_SHIFT);

	if (IsSpringLoaded())
		SetHeld((ctrlState & 0x8000) != 0);

	//
	// Yes, so now we just need to check whether it's an on or
	// off click.
	//
	if (event & PANEL_MOUSE_LBDOWN) {
		if ((Sideways == 0 && my > (y + (height / 2.0))) || (Sideways == 1 && mx < (x + (width / 2.0))) || (Sideways == 2 && mx > (x + (width / 2.0)))) {
			if (state > 0) {
				SwitchTo(state - 1, true);
				Sclick.play();
			}
		}
		else {
			if (state < 2) {
				SwitchTo(state + 1, true);
				Sclick.play();
			}
		}

	}
	else if (IsSpringLoaded() && ((event & PANEL_MOUSE_LBUP) != 0) && !IsHeld()) {		
		if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(THREEPOSSWITCH_DOWN,true);
		if (springLoaded == SPRINGLOADEDSWITCH_CENTER) SwitchTo(THREEPOSSWITCH_CENTER,true);
		if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(THREEPOSSWITCH_UP,true);

		if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == THREEPOSSWITCH_UP)     
			SwitchTo(THREEPOSSWITCH_CENTER,true);

		if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == THREEPOSSWITCH_DOWN)     
			SwitchTo(THREEPOSSWITCH_CENTER);
	}
	return true;
}

bool ThreePosSwitch::CheckMouseClickVC(int event, VECTOR3 &p)
{
	int mx, my;

	mx = x + int(p.x * width);
	my = y + int(p.y * height);

	return CheckMouseClick(event, mx, my);
}

void ThreePosSwitch::DrawSwitch(SURFHANDLE DrawSurface)

{
	oapiBlt(DrawSurface, SwitchSurface, x, y, (state * width), 0, width, height, SURF_PREDEF_CK);
}

void ThreePosSwitch::DrawSwitchVC(int id, int event, SURFHANDLE surf)
{
	if (!bHasAnimations) return;

	if (IsUp()) {
		OurVessel->SetAnimation(anim_switch, 1.0);
	}
	else if (IsCenter())
	{
		OurVessel->SetAnimation(anim_switch, 0.5);
	}
	else
	{
		OurVessel->SetAnimation(anim_switch, 0.0);
	}
}

bool ThreePosSwitch::SwitchTo(int newState, bool dontspring)

{
	if (Active)
	{
		if (state != newState)
		{
			state = newState;
			SwitchToggled = true;
			if (switchRow) {
				if (switchRow->panelSwitches->listener) 
					switchRow->panelSwitches->listener->PanelSwitchToggled(this);
			}
			if (callback)
				callback->call(this);

			if (IsSpringLoaded() && !dontspring && !IsHeld()) {
				if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(THREEPOSSWITCH_DOWN,true);
				if (springLoaded == SPRINGLOADEDSWITCH_CENTER) SwitchTo(THREEPOSSWITCH_CENTER,true);
				if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(THREEPOSSWITCH_UP,true);

				if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == THREEPOSSWITCH_UP)     
						SwitchTo(THREEPOSSWITCH_CENTER,true);

				if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == THREEPOSSWITCH_DOWN)     
						SwitchTo(THREEPOSSWITCH_CENTER,true);
			}
			return true;
		}
		if (IsSpringLoaded() && !dontspring && !IsHeld()) {
			if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   return SwitchTo(THREEPOSSWITCH_DOWN,true);
			if (springLoaded == SPRINGLOADEDSWITCH_CENTER) return SwitchTo(THREEPOSSWITCH_CENTER,true);
			if (springLoaded == SPRINGLOADEDSWITCH_UP)     return SwitchTo(THREEPOSSWITCH_UP,true);

			if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == THREEPOSSWITCH_UP)     
					return SwitchTo(THREEPOSSWITCH_CENTER,true);

			if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == THREEPOSSWITCH_DOWN)     
					return SwitchTo(THREEPOSSWITCH_CENTER,true);
		}
	}
	return false;
}

//
// Five pos switch.
//

bool FivePosSwitch::CheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	//
	// Check whether it's actually in our switch region.
	//

	if (mx < x || my < y)
		return false;

	if (mx > (x + width) || my > (y + height))
		return false;

	///
	/// \todo Get CTRL state properly if and when Orbiter supports it.
	///
	SHORT ctrlState = GetKeyState(VK_SHIFT);

	if (IsSpringLoaded())
		SetHeld((ctrlState & 0x8000) != 0);

	//
	// Yes, so now we just need to check whether it's an on or
	// off click.
	//
	// FIXME: This assumes the switch is 39x39px in size. Should be variable.
	if (event == PANEL_MOUSE_LBDOWN) {
		if (my > 24 && (mx < 30 && mx > 7)){
			// Down
			if(state != FIVEPOSSWITCH_DOWN){
				SwitchTo(FIVEPOSSWITCH_DOWN, true);
				Sclick.play();
			}
			return true;
		}
		if(my < 10 && (mx < 30 && mx > 7)){
			// Up
			if (state != FIVEPOSSWITCH_UP) {
				SwitchTo(FIVEPOSSWITCH_UP, true);
				Sclick.play();
			}
			return true;
		}
		if(mx > 30){
			// Right
			if (state != FIVEPOSSWITCH_RIGHT) {
				SwitchTo(FIVEPOSSWITCH_RIGHT, true);
				Sclick.play();
			}
			return true;
		}
		if(mx < 7){
			// Left
			if (state != FIVEPOSSWITCH_LEFT) {
				SwitchTo(FIVEPOSSWITCH_LEFT, true);
				Sclick.play();
			}
			return true;
		}
		// Otherwise
		if (state != FIVEPOSSWITCH_CENTER) {
			SwitchTo(FIVEPOSSWITCH_CENTER, true);
			Sclick.play();
		}
	} else if (IsSpringLoaded() && event == PANEL_MOUSE_LBUP && !IsHeld()) {		
		if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(FIVEPOSSWITCH_DOWN,true);
		if (springLoaded == SPRINGLOADEDSWITCH_CENTER) SwitchTo(FIVEPOSSWITCH_CENTER,true);
		if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(FIVEPOSSWITCH_UP,true);

		if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == FIVEPOSSWITCH_UP)     
			SwitchTo(FIVEPOSSWITCH_CENTER,true);

		if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == FIVEPOSSWITCH_DOWN)     
			SwitchTo(FIVEPOSSWITCH_CENTER);
	}
	return true;
}

bool FivePosSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	int OldState = state;

	///
	/// \todo Get CTRL state properly if and when Orbiter supports it.
	///
	SHORT ctrlState = GetKeyState(VK_SHIFT);

	if (IsSpringLoaded())
		SetHeld((ctrlState & 0x8000) != 0);

	//
	// Yes, so now we just need to check whether it's an on or
	// off click.
	//
	if (event == PANEL_MOUSE_LBDOWN) {
		if (p.y > 0.5 && (p.x < 0.66 && p.x > 0.33)) {
			// Down
			if (state != FIVEPOSSWITCH_DOWN) {
				SwitchTo(FIVEPOSSWITCH_DOWN, true);
				Sclick.play();
			}
			return true;
		}
		if (p.y < 0.5 && (p.x < 0.66 && p.x > 0.33)) {
			// Up
			if (state != FIVEPOSSWITCH_UP) {
				SwitchTo(FIVEPOSSWITCH_UP, true);
				Sclick.play();
			}
			return true;
		}
		if (p.x > 0.66) {
			// Right
			if (state != FIVEPOSSWITCH_RIGHT) {
				SwitchTo(FIVEPOSSWITCH_RIGHT, true);
				Sclick.play();
			}
			return true;
		}
		if (p.x < 0.33) {
			// Left
			if (state != FIVEPOSSWITCH_LEFT) {
				SwitchTo(FIVEPOSSWITCH_LEFT, true);
				Sclick.play();
			}
			return true;
		}
		// Otherwise
		if (state != FIVEPOSSWITCH_CENTER) {
			SwitchTo(FIVEPOSSWITCH_CENTER, true);
			Sclick.play();
		}
	}
	else if (IsSpringLoaded() && event == PANEL_MOUSE_LBUP && !IsHeld()) {
		if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(FIVEPOSSWITCH_DOWN, true);
		if (springLoaded == SPRINGLOADEDSWITCH_CENTER) SwitchTo(FIVEPOSSWITCH_CENTER, true);
		if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(FIVEPOSSWITCH_UP, true);

		if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == FIVEPOSSWITCH_UP)
			SwitchTo(FIVEPOSSWITCH_CENTER, true);

		if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == FIVEPOSSWITCH_DOWN)
			SwitchTo(FIVEPOSSWITCH_CENTER);
	}
	return true;
}

FivePosSwitch::FivePosSwitch()
{
	pswitchroty = NULL;
	diry = _V(0, 0, 0);
	anim_switchy = -1;
}

FivePosSwitch::~FivePosSwitch()
{
	if (pswitchroty)
		delete pswitchroty;
}

void FivePosSwitch::DrawSwitch(SURFHANDLE DrawSurface)
{
	oapiBlt(DrawSurface, SwitchSurface, x, y, (state * width), 0, width, height, SURF_PREDEF_CK);
}

void FivePosSwitch::SetDirection(const VECTOR3& _dirx, const VECTOR3 & _diry)
{
	dir = _dirx;
	diry = _diry;
	bHasDirection = true;
}

void FivePosSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasDirection && bHasReference && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), dir, (float)PI / 4);
		pswitchroty = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), diry, (float)PI / 4);
		anim_switch = OurVessel->CreateAnimation(0.5);
		anim_switchy = OurVessel->CreateAnimation(0.5);
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		OurVessel->AddAnimationComponent(anim_switchy, 0.0f, 1.0f, pswitchroty);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void FivePosSwitch::OnPostStep(double SimT, double DeltaT, double MJD)
{
	if (state == FIVEPOSSWITCH_UP) {
		OurVessel->SetAnimation(anim_switch, 0.5);
		OurVessel->SetAnimation(anim_switchy, 1.0);
	}
	else if (state == FIVEPOSSWITCH_RIGHT) {
		OurVessel->SetAnimation(anim_switch, 1.0);
		OurVessel->SetAnimation(anim_switchy, 0.5);
	}
	else if (state == FIVEPOSSWITCH_DOWN) {
		OurVessel->SetAnimation(anim_switch, 0.5);
		OurVessel->SetAnimation(anim_switchy, 0.0);
	}
	else if (state == FIVEPOSSWITCH_LEFT) {
		OurVessel->SetAnimation(anim_switch, 0.0);
		OurVessel->SetAnimation(anim_switchy, 0.5);
	}
	else {
		OurVessel->SetAnimation(anim_switch, 0.5);
		OurVessel->SetAnimation(anim_switchy, 0.5);
	}
}

bool FivePosSwitch::SwitchTo(int newState, bool dontspring)

{
	if (Active)
	{
		if (state != newState)
		{
			state = newState;
			SwitchToggled = true;
			if (switchRow) {
				if (switchRow->panelSwitches->listener) 
					switchRow->panelSwitches->listener->PanelSwitchToggled(this);
			}
			if (callback)
				callback->call(this);

			if (IsSpringLoaded() && !dontspring && !IsHeld()) {
				if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(FIVEPOSSWITCH_DOWN,true);
				if (springLoaded == SPRINGLOADEDSWITCH_CENTER) SwitchTo(FIVEPOSSWITCH_CENTER,true);
				if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(FIVEPOSSWITCH_UP,true);

				if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == FIVEPOSSWITCH_UP)     
						SwitchTo(FIVEPOSSWITCH_CENTER,true);

				if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == FIVEPOSSWITCH_DOWN)     
						SwitchTo(FIVEPOSSWITCH_CENTER,true);
			}
			return true;
		}
		if (IsSpringLoaded() && !dontspring && !IsHeld()) {
			if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   return SwitchTo(FIVEPOSSWITCH_DOWN,true);
			if (springLoaded == SPRINGLOADEDSWITCH_CENTER) return SwitchTo(FIVEPOSSWITCH_CENTER,true);
			if (springLoaded == SPRINGLOADEDSWITCH_UP)     return SwitchTo(FIVEPOSSWITCH_UP,true);

			if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == FIVEPOSSWITCH_UP)     
					return SwitchTo(FIVEPOSSWITCH_CENTER,true);

			if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == FIVEPOSSWITCH_DOWN)     
					return SwitchTo(FIVEPOSSWITCH_CENTER,true);
		}
	}
	return false;
}

//Like push button, but not springloaded
SimplePushSwitch::SimplePushSwitch()
{
	pswitchtrans = NULL;
}

SimplePushSwitch::~SimplePushSwitch()
{
	if (pswitchtrans)
		delete pswitchtrans;
}

void SimplePushSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasDirection && !bHasAnimations)
	{
		pswitchtrans = new MGROUP_TRANSLATE(vc_idx, &grpIndex, 1, GetDirection());
		anim_switch = OurVessel->CreateAnimation(InitialAnimState());
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchtrans);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

//
// Push button like switch.  Now implemented as a special case of toggle switch (springloaded and special sound)
//

void PushSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, char *dname)
{
	TwoPositionSwitch::Register(scnh, n, defaultState, 1, dname);
}

// Special case check mouse click, same result top and Bottom.
bool PushSwitch::CheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	if (!visible) return false;
	if (mx < x || my < y) return false;
	if (mx > (x + width) || my > (y + height)) return false;

	///
	/// \todo Get CTRL state properly if and when Orbiter supports it.
	///
	SHORT ctrlState = GetKeyState(VK_SHIFT);
	SetHeld((ctrlState & 0x8000) != 0);

	if (event & PANEL_MOUSE_LBDOWN) {
		SwitchTo(1, true);
		Sclick.play();
	} else if (event & PANEL_MOUSE_LBUP && !IsHeld()) {
		SwitchTo(0, true);
	}
	return true;
}

bool PushSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	int OldState = state;

	if (!visible) return false;

	///
	/// \todo Get CTRL state properly if and when Orbiter supports it.
	///
	SHORT ctrlState = GetKeyState(VK_SHIFT);
	SetHeld((ctrlState & 0x8000) != 0);

	if (event & PANEL_MOUSE_LBDOWN) {
		SwitchTo(1, true);
		Sclick.play();
	}
	else if (event & PANEL_MOUSE_LBUP && !IsHeld()) {
		SwitchTo(0, true);
	}
	return true;
}

void PushSwitch::VesimSwitchTo(int newState) {
	if (newState != state) {
		SwitchTo(newState, true);
		if (newState) Sclick.play();
	}
}

void PushSwitch::InitSound(SoundLib *s) {

	if (!Sclick.isValid())
		s->LoadSound(Sclick, BUTTON_SOUND, INTERNAL_ONLY);
}

//
// Toggled push switch.  Special case of PushSwitch
//

bool ToggledPushSwitch::CheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	if (!visible) return false;
	if (mx < x || my < y) return false;
	if (mx > (x + width) || my > (y + height)) return false;

	if (event == PANEL_MOUSE_LBDOWN) {
		if (state) {
			SwitchTo(0);
			Sclick.play();
		}
		else {
			SwitchTo(1);
			Sclick.play();
		}
	}
	return true;
}

bool ToggledPushSwitch::CheckMouseClickVC(int event, VECTOR3 &p)
{
	int OldState = state;

	if (event == PANEL_MOUSE_LBDOWN) {
		if (state) {
			SwitchTo(0);
			Sclick.play();
		}
		else {
			SwitchTo(1);
			Sclick.play();
		}
	}
	return true;
}

//
// Circuit braker switch.  Special case of Toggle Switch
//

double CircuitBrakerSwitch::Voltage()
{
	if ((GetState() != 0) && SRC)
		return SRC->Voltage();

	return 0.0;
}

double CircuitBrakerSwitch::Current()
{	
	if ((GetState() != 0) && SRC && SRC->IsEnabled()) {
		Volts = SRC->Voltage();
		if (Volts > 0.0)
			Amperes = (power_load / Volts);
		else 
			Amperes = 0.0; 
	}
	else {
		return 0.0; //remove the else part of this if it causes problems. the function is only ever called by debug strings and I find this implimentation to be more useful --n7275
	}
	return Amperes;
}

double CircuitBrakerSwitch::Frequency()
{
	if ((GetState() != 0) && SRC)
		return SRC->Frequency();

	return 0.0;
}

void CircuitBrakerSwitch::InitSound(SoundLib *s) {

	if (!Sclick.isValid())
		s->LoadSound(Sclick, CIRCUITBREAKER_SOUND, INTERNAL_ONLY);
}

void CircuitBrakerSwitch::DrawPower(double watts)

{
	/// \todo Note that this will not work properly if more than one source draws from a CB.

	// Default the power load to zero
	power_load = 0; 

	//
	// Do nothing if the breaker is open.
	//

	if (GetState() == 0){
		return;
	}

	//
	// Check the current isn't over the max rating, and if it is then
	// pop the breaker.
	//

	if (SRC) {
		double volts = SRC->Voltage();
		if (volts > 0.0) {
			double amps = watts / volts;
			if (amps > MaxAmps) {				
				state = 0;
				SwitchToggled = true;

				if (switchRow) {
					if (switchRow->panelSwitches->listener) 
						switchRow->panelSwitches->listener->PanelSwitchToggled(this);
				}
				if (callback)
					callback->call(this);
				return;
			}
		}
		
		power_load = watts; // Make this available for reading draw across a CB from later (Used in the LM)
		e_object::DrawPower(watts);
	}
}

void CircuitBrakerSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *s, double amps)

{
	SimplePushSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	if (s) {
		WireTo(s);
	}

	MaxAmps = amps;
}

//
// Attitude mode toggle switch.
//

/*bool AttitudeToggle::CheckMouseClick(int event, int mx, int my)

{
	int OldState = state;

	if (!visible)
		return false;

	if (!DoCheckMouseClick(event, mx, my))
		return false;

	if (!Active || state == OldState)
		return true;



	return true;
}*/

bool AttitudeToggle::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState,dontspring))
	{
		if (GetState()) {
			OurVessel->SetAttitudeMode(ATTMODE_ROT);
		}
		else {
			OurVessel->SetAttitudeMode(ATTMODE_LIN);
		}
		return true;
	}
	return false;
}

void AttitudeToggle::DrawSwitch(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;
	
	if (Active) {
		if (OurVessel->GetAttitudeMode() == ATTMODE_ROT) {
			state = true;
		}
		else {
			state = false;
		}
	}

	DoDrawSwitch(DrawSurface);
}

//
// HUD mode toggle switches.
//

void HUDToggle::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, int mode, SoundLib &s)

{
	HUDMode = mode;
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	row.AddSwitch(this);
}

void HUDToggle::DrawSwitch(SURFHANDLE DrawSurface)

{
	if (Active) {
		if (oapiGetHUDMode() == HUDMode) {
			state = true;
		}
		else {
			state = false;
		}
	}

	DoDrawSwitch(DrawSurface);
}

/*bool HUDToggle::CheckMouseClick(int event, int mx, int my)

{
	int OldState = state;

	if (!DoCheckMouseClick(event, mx, my))
		return false;

	if (!Active || state == OldState)
		return true;

	if (GetState()) {
		oapiSetHUDMode(HUDMode);
	}
	else {
		oapiSetHUDMode(HUD_NONE) ;
	}

	return true;
}*/

bool HUDToggle::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState,dontspring))
	{
		if (GetState()) 
		{
			oapiSetHUDMode(HUDMode);
		}
		else 
		{
			oapiSetHUDMode(HUD_NONE) ;
		}
		return true;
	}
	return false;
}

//
// NAV mode toggle switches.
//

void NavModeToggle::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, VESSEL *v, int mode, SoundLib &s)

{
	NAVMode = mode;
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
}

void NavModeToggle::DrawSwitch(SURFHANDLE DrawSurface)

{
	if (Active) {
		if (OurVessel->GetNavmodeState(NAVMode)) {
			state = true;
		}
		else {
			state = false;
		}
	}

	DoDrawSwitch(DrawSurface);
}

/*bool NavModeToggle::CheckMouseClick(int event, int mx, int my)

{
	int OldState = state;

	if (!DoCheckMouseClick(event, mx, my))
		return false;

	if (!Active || state == OldState)
		return true;

	if (GetState()) {
		OurVessel->ActivateNavmode(NAVMode);
	}
	else {
		OurVessel->DeactivateNavmode(NAVMode) ;
	}

	return true;
}*/

bool NavModeToggle::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState,dontspring))
	{
		if (GetState())
		{
			OurVessel->ActivateNavmode(NAVMode);
		}
		else
		{
			OurVessel->ActivateNavmode(NAVMode);
		}
		return true;
	}
	return false;
}

//
// Switch row support.
//

SwitchRow::SwitchRow() {

	SwitchList = 0;
	RowList = 0;
	PanelArea = (-1);

	RowPower = 0;
}

SwitchRow::~SwitchRow() {
}

bool SwitchRow::CheckMouseClick(int id, int event, int mx, int my) {

	if (id != PanelArea)
		return false;

	PanelSwitchItem *s = SwitchList;
	while (s) {
		if (s->CheckMouseClick(event, mx, my))
			return true;
		s = s->GetNext();
	}
	return false;
}

void SwitchRow::timestep(double missionTime)
{
	PanelSwitchItem *s = SwitchList;
	while (s)
	{
		if (s->doTimeStep)
			s->timestep(missionTime);
		s = s->GetNext();
	}
}

void SwitchRow::AddSwitch(PanelSwitchItem *s)

{
	s->SetNext(SwitchList); 
	SwitchList = s;

	//
	// If we have power, wire it to the switch. Unless someone's already connected it
	// to another power source.
	//
	if (RowPower && !(s->IsWired()))
		s->WireTo(RowPower);
}

PanelSwitchItem *SwitchRow::GetItemByName(const char *n)

{
	if (!n)
		return 0;

	PanelSwitchItem *s = SwitchList;
	while (s) {
		char *nm = s->GetName();
		if (nm && !strcmp(nm, n))
		{
			return s;
		}

		s = s->GetNext();
	}

	return 0;
}

void SwitchRow::Init(int area, PanelSwitches &panel, e_object *p) {

	SwitchList = 0;
	RowList = 0;
	PanelArea = area;
	panelSwitches = &panel;
	RowPower = p;

	panel.AddRow(this);
}

bool SwitchRow::DrawRow(int id, SURFHANDLE DrawSurface, bool FlashOn) {

	if (id != PanelArea)
		return false;

	PanelSwitchItem *s = SwitchList;
	while (s) {
		s->DrawSwitch(DrawSurface);
		if (FlashOn && s->IsFlashing())
			s->DrawFlash(DrawSurface);
		s = s->GetNext();
	}
	return true;
}

void PanelSwitchesVC::DefineVCAnimations(UINT vcidx)
{
	for (unsigned int i = 0; i < SwitchList.size(); i++)
		SwitchList.at(i)->DefineVCAnimations(vcidx);
}

bool PanelSwitchesVC::VCMouseEvent(int id, int event, VECTOR3 &p)
{
	for (unsigned i = 0;i < SwitchList.size();i++)
	{
		if (id == SwitchArea[i])
		{
			return SwitchList[i]->CheckMouseClickVC(event, p);
		}
	}
	return false;
}

bool PanelSwitchesVC::VCRedrawEvent(int id, int event, SURFHANDLE surf)
{
	bool bRedraw = false;
	for (unsigned i = 0;i < SwitchList.size();i++)
	{
		if (id == SwitchArea[i])
		{
			SwitchList[i]->DrawSwitchVC(id, event, surf);
			bRedraw = true;
		}
	}
	return bRedraw;
}

void PanelSwitchesVC::OnPostStep(double SimT, double DeltaT, double MJD)
{
	for (unsigned i = 0;i < SwitchList.size();i++)
	{
		SwitchList[i]->OnPostStep(SimT, DeltaT, MJD);
	}
}

void PanelSwitchesVC::OnPostCreation()
{
	for (unsigned i = 0; i < SwitchList.size(); i++)
	{
		SwitchList[i]->OnPostCreation();
	}
}


void PanelSwitchesVC::AddSwitch(PanelSwitchItem *s, int area)
{
	SwitchList.push_back(s);
	SwitchArea.push_back(area);
}

void PanelSwitchesVC::ClearSwitches()
{
	SwitchList.clear();
	SwitchArea.clear();
}

PanelSwitchItem *PanelSwitchesVC::GetFlashingItem()
{
    for (unsigned i = 0; i < SwitchList.size(); i++)
    {
        if (SwitchList[i]->IsFlashing())
        {
            return SwitchList[i];
        }
    }
    return NULL;
}

//
// Panel of switches. This code wraps up a whole panel with multiple
// rows of switches, and passes redraw and mouse events to the appropriate
// switches.
//

bool PanelSwitches::CheckMouseClick(int id, int event, int mx, int my) {

	SwitchRow *row = RowList;

	while (row) {
		if (row->CheckMouseClick(id, event, mx, my))
			return true;
		row = row->GetNext();
	}

	return false;
}

void PanelSwitches::timestep(double missionTime)
{
	if (missionTime < (lastexecutedtime + 1))
		return;
	if (missionTime > (lastexecutedtime + 2))
		lastexecutedtime = missionTime;
	else
		lastexecutedtime += 1;
	SwitchRow *row = RowList;

	while (row) {
		row->timestep(missionTime);
		row = row->GetNext();
	}
}

bool PanelSwitches::DrawRow(int id, SURFHANDLE DrawSurface, bool FlashOn) {

	SwitchRow *row = RowList;

	while (row) {
		if (row->DrawRow(id, DrawSurface, FlashOn))
			return true;
		row = row->GetNext();
	}

	return false;
}

bool PanelSwitches::SetFlashing(const char *n, bool flash)

{
	PanelSwitchItem *p;
	SwitchRow *row = RowList;

	while (row) {
		p = row->GetItemByName(n);
		if (p)
		{
			p->SetFlashing(flash);
/*
			if (flash) {
				nextActiveSwitch = p;
			}else{
				nextActiveSwitch = nullptr;
			}
*/
			return true;
		}

		row = row->GetNext();
	}

	return false;
}

bool PanelSwitches::GetFlashing(const char *n) {

	PanelSwitchItem *p;
	SwitchRow *row = RowList;

	while (row) {
		p = row->GetItemByName(n);
		if (p) {
			return p->IsFlashing();
		}
		row = row->GetNext();
	}
	return false;
}

int PanelSwitches::GetState(const char *n)

{
	PanelSwitchItem *p;
	SwitchRow *row = RowList;

	while (row) {
		p = row->GetItemByName(n);
		if (p)
		{
			return p->GetState();
		}

		row = row->GetNext();
	}

	return -1;
}

void PanelSwitches::SetFailedState(const char *n, bool fail, int fail_state)
{
	PanelSwitchItem *p;
	SwitchRow *row = RowList;

	while (row) {
		p = row->GetItemByName(n);
		if (p)
		{
			p->SetFailed(fail, fail_state);
			return;
		}
		row = row->GetNext();
	}
}

bool PanelSwitches::GetFailedState(const char *n)

{
	PanelSwitchItem *p;
	SwitchRow *row = RowList;

	while (row) {
		p = row->GetItemByName(n);
		if (p)
		{
			return p->IsFailed();
		}

		row = row->GetNext();
	}

	return false;
}

bool PanelSwitches::SetState(const char *n, int value, bool guard, bool hold)

{
	PanelSwitchItem *p;
	SwitchRow *row = RowList;

	while (row) {
		p = row->GetItemByName(n);
		if (p) {
			p->Unguard();
			p->SetHeld(hold);
			p->SetState(value);
			if (guard)
				p->Guard();			
			return true;
		}
		row = row->GetNext();
	}

	/// \todo When false is returned, the checklist controller loops infinitely, better solution?
	// return false;
	sprintf(oapiDebugString(),"Switch not found: %s", n);
	return true;

}

SwitchCover::SwitchCover()
{
	guardAnim = -1;
	pcoverrot = NULL;
	coverGrpIndex = 0;
	coverreference = _V(0, 0, 0);
	coverdir = _V(0, 0, 0);
	coverrotation = 0.0;
}

SwitchCover::~SwitchCover()
{
	if (pcoverrot)
		delete pcoverrot;
}

const VECTOR3& SwitchCover::GetCoverReference() const
{
	return coverreference;
}

const VECTOR3& SwitchCover::GetCoverDirection() const
{
	return coverdir;
}

void SwitchCover::SetCoverRotationAngle(const double rot)
{
	coverrotation = rot;
}

const double& SwitchCover::GetCoverRotation() const
{
	return coverrotation;
}

//
// Guarded toggle switch.
//

GuardedToggleSwitch::GuardedToggleSwitch() {
	
	guardX = 0;
	guardY = 0;
	guardWidth = 0;
	guardHeight = 0;
	guardSurface = 0;
	guardState = 0;
	guardResetsState = true;
}

GuardedToggleSwitch::~GuardedToggleSwitch() {
}

void GuardedToggleSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, int defaultGuardState, int springloaded) 
{
	ToggleSwitch::Register(scnh, n, defaultState, springloaded, 0);
	guardState = defaultGuardState;
}

void GuardedToggleSwitch::InitGuard(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf,
									int xOffset, int yOffset) {
	guardX = xp;
	guardY = yp;
	guardWidth = w;
	guardHeight = h;

	guardSurface = surf;
	guardBorder = bsurf;
	
	guardXOffset = xOffset;
	guardYOffset = yOffset;

	if (!guardClick.isValid())
		switchRow->panelSwitches->soundlib->LoadSound(guardClick, GUARD_SOUND, INTERNAL_ONLY);
}

void GuardedToggleSwitch::DrawSwitch(SURFHANDLE DrawSurface) {

	if (!visible) return;

	if (guardResetsState) { 
		if (guardState) {
			oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			DoDrawSwitch(DrawSurface);
		} else {
			DoDrawSwitch(DrawSurface);
			oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
		}
	} else {
		if (guardState) {
			oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			DoDrawSwitch(DrawSurface);
		} else {
			if (state) {
				oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + 3 * guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			} else {
				oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			}
		}
	}
}

void GuardedToggleSwitch::DrawSwitchVC(int id, int event, SURFHANDLE surf) {

	ToggleSwitch::DrawSwitchVC(id, event, surf);

	if (guardAnim != -1) {
		if (guardState) {
			OurVessel->SetAnimation(guardAnim, 1.0);
		}
		else {
			OurVessel->SetAnimation(guardAnim, 0.0);
		}
	}
}

void GuardedToggleSwitch::DrawFlash(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;

	if (!guardState && guardBorder)
		oapiBlt(DrawSurface, guardBorder, guardX, guardY, 0, 0, guardWidth, guardHeight, SURF_PREDEF_CK);
	else
		ToggleSwitch::DrawFlash(DrawSurface);
}

void GuardedToggleSwitch::Guard() {

	if (guardState) {
		guardState = 0;

		// reset by guard
		if (guardResetsState) { 
			if (Active && state) {
				SwitchTo(TOGGLESWITCH_DOWN);
			}
		}
		// reset by spring
		if (IsSpringLoaded()) {
			if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(TOGGLESWITCH_DOWN,true);
			if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(TOGGLESWITCH_UP,true);
		}

	} 
}

bool GuardedToggleSwitch::CheckMouseClick(int event, int mx, int my) {

	if (!visible) return false;

	if (event & PANEL_MOUSE_RBDOWN) {
		if (mx >= guardX && mx <= guardX + guardWidth && 
			my >= guardY && my <= guardY + guardHeight) {			
			if (guardState) {
				Guard();
			} 
			else {
				guardState = 1;
			}
			guardClick.play();
			return true;
		}
	}
	else if (event & (PANEL_MOUSE_LBDOWN | PANEL_MOUSE_LBUP)) {
		if (guardState) {
			return ToggleSwitch::CheckMouseClick(event, mx, my);
		}
	}
	return false;
}

void GuardedToggleSwitch::DefineMeshGroup(UINT _grpIndex, UINT _coverGrpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
	coverGrpIndex = _coverGrpIndex;
}

void GuardedToggleSwitch::SetReference(const VECTOR3& ref, const VECTOR3& coverref, const VECTOR3& _dir, const VECTOR3& _coverdir)
{
	bHasReference = true;
	bHasDirection = true;
	reference = ref;
	coverreference = coverref;
	coverdir = _coverdir;
	dir = _dir;
}

void GuardedToggleSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		ToggleSwitch::DefineVCAnimations(vc_idx);
		pcoverrot = new MGROUP_ROTATE(vc_idx, &coverGrpIndex, 1, GetCoverReference(), GetCoverDirection(), (float)(RAD * 90));
		guardAnim = OurVessel->CreateAnimation(0.0);
		OurVessel->AddAnimationComponent(guardAnim, 0.0f, 1.0f, pcoverrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

bool GuardedToggleSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	int mx, my;

	mx = x + int(p.x * width);
	my = y + int(p.y * height);

	return CheckMouseClick(event, mx, my);
}

void GuardedToggleSwitch::VesimSwitchTo(int newState) {
	if (guardState) {
		return ToggleSwitch::VesimSwitchTo(newState);
	}
}

void GuardedToggleSwitch::SaveState(FILEHANDLE scn) {

	char buffer[100];

	sprintf(buffer, "%i %i", state, guardState); 
	oapiWriteScenario_string(scn, name, buffer);
}

void GuardedToggleSwitch::LoadState(char *line) {
	
	char buffer[100];
	int st, gst;

	sscanf(line, "%s %i %i", buffer, &st, &gst); 
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
		guardState = gst;
	}
}


//
// Guarded push switch.
//

GuardedPushSwitch::GuardedPushSwitch() {
	
	guardX = 0;
	guardY = 0;
	guardWidth = 0;
	guardHeight = 0;
	guardSurface = 0;
	guardBorder = 0;
	guardState = 0;
	guardResetsState = true;

	lit = false;
}

GuardedPushSwitch::~GuardedPushSwitch() {
}

void GuardedPushSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, int xoffset, int yoffset, int lxoffset, int lyoffset)

{
	litOffsetX = lxoffset;
	litOffsetY = lyoffset;

	TwoPositionSwitch::Init(xp, yp, w, h, surf, bsurf, row, xoffset, yoffset);
}

void GuardedPushSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, int defaultGuardState) {

	PushSwitch::Register(scnh, n, defaultState, 0);
	guardState = defaultGuardState;
}

void GuardedPushSwitch::InitGuard(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf,
									int xOffset, int yOffset) {
	guardX = xp;
	guardY = yp;
	guardWidth = w;
	guardHeight = h;

	guardSurface = surf;
	guardBorder = bsurf;
	
	guardXOffset = xOffset;
	guardYOffset = yOffset;

	if (!guardClick.isValid())
		switchRow->panelSwitches->soundlib->LoadSound(guardClick, GUARD_SOUND, INTERNAL_ONLY);
}

void GuardedPushSwitch::DefineMeshGroup(UINT _grpIndex, UINT _coverGrpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
	coverGrpIndex = _coverGrpIndex;
}

void GuardedPushSwitch::DoDrawSwitch(SURFHANDLE DrawSurface)

{
	if (lit)
	{
		oapiBlt(DrawSurface, SwitchSurface, x, y, litOffsetX, litOffsetY, width, height, SURF_PREDEF_CK);
	}
	else
		TwoPositionSwitch::DoDrawSwitch(DrawSurface);
}

void GuardedPushSwitch::DrawSwitch(SURFHANDLE DrawSurface) {

	if (!visible) return;

	if(guardState)
	{
		oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
		DoDrawSwitch(DrawSurface);
	}
	else
	{
		DoDrawSwitch(DrawSurface);
		oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
	}
}

void GuardedPushSwitch::SetReference(const VECTOR3& _dir, const VECTOR3& coverref, const VECTOR3& ref, const VECTOR3& _coverdir)
{
	bHasReference = true;
	bHasDirection = true;
	dir = _dir;
	coverreference = coverref;
	reference = ref;
	coverdir = _coverdir;
}

void GuardedPushSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		PushSwitch::DefineVCAnimations(vc_idx);
		pcoverrot = new MGROUP_ROTATE(vc_idx, &coverGrpIndex, 1, GetCoverReference(), GetCoverDirection(), (float)(GetCoverRotation()));
		guardAnim = OurVessel->CreateAnimation(0.0);
		OurVessel->AddAnimationComponent(guardAnim, 0.0f, 1.0f, pcoverrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void GuardedPushSwitch::DrawSwitchVC(int id, int event, SURFHANDLE surf) {

	PushSwitch::DrawSwitchVC(id, event, surf);

	if (guardAnim != -1) {
		if (guardState) {
			OurVessel->SetAnimation(guardAnim, 1.0);
		}
		else {
			OurVessel->SetAnimation(guardAnim, 0.0);
		}
	}
}

void GuardedPushSwitch::DrawFlash(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;

	if (!guardState && guardBorder)
		oapiBlt(DrawSurface, guardBorder, guardX, guardY, 0, 0, guardWidth, guardHeight, SURF_PREDEF_CK);
	else
		TwoPositionSwitch::DrawFlash(DrawSurface);
}

void GuardedPushSwitch::Guard() {
			
	if (guardState) {
		guardState = 0;
		if (Active && state && guardResetsState)
			SwitchTo(0,true);
	}
}

bool GuardedPushSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (!visible) return false;

	if (event & PANEL_MOUSE_RBDOWN) {
		if (mx >= guardX && mx <= guardX + guardWidth && 
			my >= guardY && my <= guardY + guardHeight) {			
			if (guardState) {
				Guard();
			}
			else {
				guardState = 1;
			}
			guardClick.play();
			return true;
		}
	}
	else if (event & (PANEL_MOUSE_LBDOWN | PANEL_MOUSE_LBUP)) {
		if (guardState) {
			return PushSwitch::CheckMouseClick(event, mx, my);
		}
	}
	return false;
}

bool GuardedPushSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	if (event & PANEL_MOUSE_RBDOWN) {

		if (guardState) {
			Guard();
		}
		else {
			guardState = 1;
		}
		guardClick.play();
		return true;

	}
	else if (event & (PANEL_MOUSE_LBDOWN | PANEL_MOUSE_LBUP)) {
		if (guardState) {
			return PushSwitch::CheckMouseClickVC(event, p);
		}
	}
	return false;
}

void GuardedPushSwitch::SaveState(FILEHANDLE scn) {

	char buffer[100];

	sprintf(buffer, "%i %i %d", state, guardState, lit ? 1 : 0); 
	oapiWriteScenario_string(scn, name, buffer);
}

void GuardedPushSwitch::LoadState(char *line) {
	
	char buffer[100];
	int st, gst, l = 0;

	//
	// Note we set l to zero before the sscanf call to allow backward
	// compatibility with old scenarios: default to unlit if the lit
	// state isn't saved in the file.
	//
	sscanf(line, "%s %i %i %d", buffer, &st, &gst, &l); 
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
		guardState = gst;
		lit = (l != 0);
	}
}


//
// Guarded three pos switch.
//

GuardedThreePosSwitch::GuardedThreePosSwitch() {
	
	guardX = 0;
	guardY = 0;
	guardWidth = 0;
	guardHeight = 0;
	guardSurface = 0;
	guardState = 0;
}

GuardedThreePosSwitch::~GuardedThreePosSwitch() {
}

void GuardedThreePosSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, int defaultGuardState, 
									 int springloaded) 
{
	ThreePosSwitch::Register(scnh, n, defaultState, springloaded, 0);
	guardState = defaultGuardState;
}

void GuardedThreePosSwitch::InitGuard(int xp, int yp, int w, int h, SURFHANDLE surf, 
									  int xOffset, int yOffset) {
	guardX = xp;
	guardY = yp;
	guardWidth = w;
	guardHeight = h;
	guardSurface = surf;
	guardXOffset = xOffset;
	guardYOffset = yOffset;

	if (!guardClick.isValid())
		switchRow->panelSwitches->soundlib->LoadSound(guardClick, GUARD_SOUND, INTERNAL_ONLY);
}

void GuardedThreePosSwitch::DefineMeshGroup(UINT _grpIndex, UINT _coverGrpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
	coverGrpIndex = _coverGrpIndex;
}

void GuardedThreePosSwitch::SetReference(const VECTOR3& ref, const VECTOR3& coverref, const VECTOR3& _dir, const VECTOR3& _coverdir)
{
	bHasReference = true;
	bHasDirection = true;
	reference = ref;
	coverreference = coverref;
	coverdir = _coverdir;
	dir = _dir;
}

void GuardedThreePosSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		ToggleSwitch::DefineVCAnimations(vc_idx);
		pcoverrot = new MGROUP_ROTATE(vc_idx, &coverGrpIndex, 1, GetCoverReference(), GetCoverDirection(), (float)(RAD * 90));
		guardAnim = OurVessel->CreateAnimation(0.0);
		OurVessel->AddAnimationComponent(guardAnim, 0.0f, 1.0f, pcoverrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void GuardedThreePosSwitch::DrawSwitch(SURFHANDLE DrawSurface) {

	if (!visible) return;

	if (guardResetsState) { 
		if(guardState) {
			oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			ThreePosSwitch::DrawSwitch(DrawSurface);
		} else {
			oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
		}
	} else {
		if (guardState) {
			oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			ThreePosSwitch::DrawSwitch(DrawSurface);
		} else {
			if (state == THREEPOSSWITCH_DOWN) {
				oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			} else if (state == THREEPOSSWITCH_CENTER) {
				oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + 2 * guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			} else {
				oapiBlt(DrawSurface, guardSurface, guardX, guardY, guardXOffset + 3 * guardWidth, guardYOffset, guardWidth, guardHeight, SURF_PREDEF_CK);
			}
		}
	}
}

void GuardedThreePosSwitch::DrawSwitchVC(int id, int event, SURFHANDLE surf) {

	ThreePosSwitch::DrawSwitchVC(id, event, surf);

	if (guardAnim != -1) {
		if (guardState) {
			OurVessel->SetAnimation(guardAnim, 1.0);
		}
		else {
			OurVessel->SetAnimation(guardAnim, 0.0);
		}
	}
}

void GuardedThreePosSwitch::Guard() {

	if (guardState) {
		guardState = 0;
		// reset by guard
		if (guardResetsState) { 
			if (Active && state) {
				SwitchTo(THREEPOSSWITCH_DOWN,true);
			}
		}
		// reset by spring
		if (IsSpringLoaded()) {
			if (springLoaded == SPRINGLOADEDSWITCH_DOWN)   SwitchTo(THREEPOSSWITCH_DOWN,true);
			if (springLoaded == SPRINGLOADEDSWITCH_CENTER) SwitchTo(THREEPOSSWITCH_CENTER,true);
			if (springLoaded == SPRINGLOADEDSWITCH_UP)     SwitchTo(THREEPOSSWITCH_UP,true);

			if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGUP && state == THREEPOSSWITCH_UP)     
				SwitchTo(THREEPOSSWITCH_CENTER,true);

			if (springLoaded == SPRINGLOADEDSWITCH_CENTER_SPRINGDOWN && state == THREEPOSSWITCH_DOWN)     
				SwitchTo(THREEPOSSWITCH_CENTER,true);
		}
	}
}

bool GuardedThreePosSwitch::CheckMouseClick(int event, int mx, int my) {

	if (!visible) return false;

	if (event & PANEL_MOUSE_RBDOWN) {
		if (mx >= guardX && mx <= guardX + guardWidth && 
			my >= guardY && my <= guardY + guardHeight) {			
			if (guardState) {
				Guard();
			} else {
				guardState = 1;
			}
			guardClick.play();
			return true;
		}
	} else if (event & (PANEL_MOUSE_LBDOWN | PANEL_MOUSE_LBUP)) {
		if (guardState) {
			return ThreePosSwitch::CheckMouseClick(event, mx, my);
		}
	}
	return false;
}

bool GuardedThreePosSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	int mx, my;

	mx = x + int(p.x * width);
	my = y + int(p.y * height);

	return CheckMouseClick(event, mx, my);
}

void GuardedThreePosSwitch::SaveState(FILEHANDLE scn) {

	char buffer[100];

	sprintf(buffer, "%i %i", state, guardState); 
	oapiWriteScenario_string(scn, name, buffer);
}

void GuardedThreePosSwitch::LoadState(char *line) {
	
	char buffer[100];
	int st, gst;

	sscanf(line, "%s %i %i", buffer, &st, &gst); 
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
		guardState = gst;
	}
}

ContinuousSwitch::ContinuousSwitch()
{
	state = 0.0;
	minValue = 0.0;
	maxValue = 1.0;
	slope = 1.0;
	Wraparound = false;

	grpIndex = NULL;
	pswitchrot = NULL;
	anim_switch = NULL;

	OurVessel = NULL;

	x = 0;
	y = 0;
	width = 0;
	height = 0;
	maxState = 1;
	switchSurface = 0;
	switchBorder = 0;
	switchRow = 0;

	RotationRange = 0.0;
}

ContinuousSwitch::~ContinuousSwitch()
{
	if (pswitchrot)
		delete pswitchrot;
}

void ContinuousSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, double defaultVal, double minVal, double maxVal)
{
	//defaultValue: default display value (e.g. 0�)
	//minValue: minimum displayed value (e.g. -4�)
	//maxValue: maximum displayed value (e.g. +4�)
	//maxState: maximum number of bitmap positions

	minValue = minVal;
	maxValue = maxVal;

	slope = 1.0 / (maxValue - minValue);

	name = n;
	SetValue(DisplayToAngle(defaultVal));
	scnh.RegisterSwitch(this);
}

void ContinuousSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row)
{
	x = xp;
	y = yp;
	width = w;
	height = h;

	switchSurface = surf;
	switchBorder = bsurf;

	row.AddSwitch(this);
	switchRow = &row;

	OurVessel = switchRow->panelSwitches->vessel;
}

void ContinuousSwitch::SetWraparound(bool _Wraparound)
{
	Wraparound = _Wraparound;
}

double ContinuousSwitch::GetValue()
{
	//Returns value of displayed state
	return AngletoDisplay(state);
}

double ContinuousSwitch::GetOutput()
{
	return state;
}

void ContinuousSwitch::SetRotationRange(double _range)
{
	RotationRange = _range;
}

void ContinuousSwitch::SetState(int value)
{
	//This function called by checklist controller
	SwitchTo(DisplayToAngle((double)value));
}

int ContinuousSwitch::GetState()
{
	//Return to checklist controller
	double value = AngletoDisplay(state);

	if (value < 0.0)
	{
		return (int)(value - 0.5);
	}
	return (int)(value + 0.5);
}

bool ContinuousSwitch::SwitchTo(double newPosition)
{
	//Remember old state
	double oldState = state;
	//Actually change state
	SetValue(newPosition);
	//Did it change?
	if (state != oldState)
	{
		//Play sound
		if (sclick.isValid()) sclick.play();
		return true;
	}
	return false;
}

void ContinuousSwitch::SetValue(double newAngle)
{
	//Limit
	if (Wraparound)
	{
		while (newAngle < 0.0)
		{
			newAngle += 1.0;
		}
		while (newAngle >= 1.0)
		{
			newAngle -= 1.0;
		}
	}
	else
	{
		if (newAngle < 0.0)
		{
			newAngle = 0.0;
		}
		else if (newAngle > 1.0)
		{
			newAngle = 1.0;
		}
	}

	state = newAngle;
}

double ContinuousSwitch::DisplayToAngle(double value) const
{
	return slope * (value - minValue);
}

double ContinuousSwitch::AngletoDisplay(double angle) const
{
	return minValue + angle / slope;
}

void ContinuousSwitch::SetInitValue(double defaultValue)
{
	SetValue(DisplayToAngle(defaultValue));
}

void ContinuousSwitch::DefineMeshGroup(UINT _grpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
}

void ContinuousSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), GetDirection(), (float)(RotationRange));
		anim_switch = OurVessel->CreateAnimation(InitialAnimState());
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void ContinuousSwitch::DrawFlash(SURFHANDLE drawSurface)
{
	if (!visible)
		return;

	if (switchBorder)
		oapiBlt(drawSurface, switchBorder, x, y, 0, 0, width, height, SURF_PREDEF_CK);
}

void ContinuousSwitch::DrawSwitchVC(int id, int event, SURFHANDLE drawSurface)
{
	if (!bHasAnimations) return;
	OurVessel->SetAnimation(anim_switch, state);
}

void ContinuousSwitch::SaveState(FILEHANDLE scn)
{
	oapiWriteScenario_float(scn, name, state);
}

void ContinuousSwitch::LoadState(char *line)
{
	char buffer[100];
	double st;

	sscanf(line, "%s %lf", buffer, &st);
	if (!strnicmp(buffer, name, strlen(name)))
	{
		SetValue(st);
	}
}

void ContinuousSwitch::LoadSound(char *soundname)
{
	if (!sclick.isValid()) {
		switchRow->panelSwitches->soundlib->LoadSound(sclick, soundname);
	}
}

ContinuousThumbwheelSwitch::ContinuousThumbwheelSwitch()
{
	maxState = 17;
	isHorizontal = false;
	clickIncrement = 0.0;
}

ContinuousThumbwheelSwitch::~ContinuousThumbwheelSwitch()
{

}

void ContinuousThumbwheelSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, double defaultValue, double minValue, double maxValue, double clickIncr, bool horizontal)
{
	ContinuousSwitch::Register(scnh, n, defaultValue, minValue, maxValue);

	isHorizontal = horizontal;
	clickIncrement = clickIncr * abs(slope); //clickIncrement in units of actual state 0.0-1.0
}

void ContinuousThumbwheelSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row)
{
	ContinuousSwitch::Init(xp, yp, w, h, surf, bsurf, row);

	LoadSound(THUMBWHEEL_SOUND);
}

void ContinuousThumbwheelSwitch::SetState(int value)
{
	//This function called by checklist controller. Input is integer, so to get fine control this assumes the checklist has a value of 10x the desired one
	SwitchTo(DisplayToAngle((double)(value) / 10.0));
}

int ContinuousThumbwheelSwitch::GetState()
{
	//Return to checklist controller
	double value = AngletoDisplay(state)*10.0;

	if (value < 0.0)
	{
		return (int)(value - 0.5);
	}
	return (int)(value + 0.5);
}

void ContinuousThumbwheelSwitch::DrawSwitch(SURFHANDLE drawSurface)
{
	//Scaled to number of bitmap positions
	double val2 = state * (double)(maxState - 1);
	//Same in integer
	int srcx = (int)(val2 + 0.5);

	oapiBlt(drawSurface, switchSurface, x, y, srcx * width, 0, width, height, SURF_PREDEF_CK);
}

bool ContinuousThumbwheelSwitch::CheckMouseClick(int event, int mx, int my)
{
	//
	// Check whether it's actually in our switch region.
	//

	if (mx < x || my < y)
		return false;

	if (mx > (x + width) || my > (y + height))
		return false;

	//
	// Yes, so now we just need to check whether it's an on or
	// off click.
	//

	if (event == PANEL_MOUSE_LBDOWN || event == PANEL_MOUSE_RBDOWN)
	{
		//Choose increment
		double incr = clickIncrement;
		if (event == PANEL_MOUSE_RBDOWN) incr *= 0.2;

		bool positive = false;

		if (isHorizontal)
		{
			if (mx < (x + (width / 2.0))) positive = true;
		}
		else
		{
			if (my < (y + (height / 2.0))) positive = true;
		}

		if (positive)
		{
			SwitchTo(state + incr);
		}
		else
		{
			SwitchTo(state - incr);
		}
	}

	return true;
}

bool ContinuousThumbwheelSwitch::CheckMouseClickVC(int event, VECTOR3 &p)
{
	if (event == PANEL_MOUSE_LBDOWN || event == PANEL_MOUSE_RBDOWN)
	{
		//Choose increment
		double incr = clickIncrement;
		if (event == PANEL_MOUSE_RBDOWN) incr *= 0.2;

		bool positive = false;

		if (isHorizontal)
		{
			if (p.x < 0.5) positive = true;
		}
		else
		{
			if (p.y < 0.5) positive = true;
		}

		if (positive)
		{
			SwitchTo(state + incr);
		}
		else
		{
			SwitchTo(state - incr);
		}
	}

	return true;
}


ContinuousRotationalSwitch::ContinuousRotationalSwitch()
{
	maxState = 24;
	lastX = 0.0;
	mouseDown = false;
	rotOffset = 0.0;
}

ContinuousRotationalSwitch::~ContinuousRotationalSwitch()
{

}

void ContinuousRotationalSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row)
{
	ContinuousSwitch::Init(xp, yp, w, h, surf, bsurf, row);
}

void ContinuousRotationalSwitch::SetOffset(double Offset)
{
	//Angle by which the switch has to be rotated from the up position to an animation state of zero, i.e. usually the minimum position
	rotOffset = Offset;
}

void ContinuousRotationalSwitch::DrawSwitch(SURFHANDLE drawSurface)
{
	//Convert animation state to bitmap state (0-1)
	double val = (rotOffset + state * RotationRange) / PI2;
	if (val < 0.0)
	{
		val += 1.0;
	}
	//Scaled to number of bitmap positions
	double val2 = val * (double)(maxState);
	//Same in integer
	int srcx = (int)(val2 + 0.5);
	//Overflow
	if (srcx < 0)
	{
		srcx = 0;
	}
	if (srcx >= maxState)
	{
		srcx -= maxState;
	}
	//Default bitmap has alternating 15� positions up and down
	int srcx2, srcy;
	if (maxState > 12)
	{
		if (srcx % 2 == 0)
		{
			srcy = 0;
		}
		else
		{
			srcy = 1;
		}
		srcx2 = srcx / 2;
	}
	else
	{
		//Bitmap with only 12 switch positions
		srcx2 = srcx;
		srcy = 0;
	}

	oapiBlt(drawSurface, switchSurface, x, y, srcx2 * width, srcy*height, width, height, SURF_PREDEF_CK);
}

bool ContinuousRotationalSwitch::CheckMouseClick(int event, int mx, int my)
{
	if (event & PANEL_MOUSE_LBDOWN)
	{
		// Check whether it's actually in our switch region.
		if (mx < x || my < y)
			return false;

		if (mx > (x + width) || my > (y + height))
			return false;

		//Mouse click to start
		lastX = ((double)(mx - x)) / ((double)(width));
		mouseDown = true;

		return true;
	}
	else if (((event & PANEL_MOUSE_LBPRESSED) != 0) && mouseDown)
	{
		//Process held left mouse button
		double px;
		px = ((double)(mx - x)) / ((double)(width));

		ChangeSwitchState(px);
		return true;
	}
	else if (event & PANEL_MOUSE_LBUP && mouseDown)
	{
		//Stop
		mouseDown = false;
		return false;
	}
	return false;
}

bool ContinuousRotationalSwitch::CheckMouseClickVC(int event, VECTOR3 &p)
{
	if (event & PANEL_MOUSE_LBDOWN)
	{
		//Mouse click to start
		lastX = p.x;
		mouseDown = true;
	}
	else if (((event & PANEL_MOUSE_LBPRESSED) != 0) && mouseDown)
	{
		ChangeSwitchState(p.x);
	}
	else if (event & PANEL_MOUSE_LBUP)
	{
		//Stop
		mouseDown = false;
		return false;
	}
	return true;
}

void ContinuousRotationalSwitch::ChangeSwitchState(double px)
{
	if (abs(px - lastX) >= 0.01)
	{
		//Increase state by difference in mouse position
		double incr = 60.0*RAD / RotationRange * (px - lastX);
		//Update state
		SwitchTo(state + incr);
		//Save last position
		lastX = px;
	}
}

//
// Rotational Switch
//

RotationalSwitch::RotationalSwitch() {

	x = 0;
	y = 0;
	width = 0;
	height = 0;
	position = 0;
	positionList = 0;
	next = 0;
	soundEnabled = true;
	maxState = -1;
	Wraparound = false;

	anim_switch = NULL;
	pswitchrot = NULL;
	grpIndex = 0;

	switchSurface = 0;
	switchBorder = 0;
	
	switchRow = 0;

	bitmaps[0].angle = 0;
	bitmaps[0].xOffset = 0;
	bitmaps[0].yOffset = 0;

	bitmaps[1].angle = 30;
	bitmaps[1].xOffset = 1;
	bitmaps[1].yOffset = 0;

	bitmaps[2].angle = 60;
	bitmaps[2].xOffset = 2;
	bitmaps[2].yOffset = 0;

	bitmaps[3].angle = 90;
	bitmaps[3].xOffset = 3;
	bitmaps[3].yOffset = 0;

	bitmaps[4].angle = 120;
	bitmaps[4].xOffset = 4;
	bitmaps[4].yOffset = 0;

	bitmaps[5].angle = 150;
	bitmaps[5].xOffset = 5;
	bitmaps[5].yOffset = 0;

	bitmaps[6].angle = 180;
	bitmaps[6].xOffset = 6;
	bitmaps[6].yOffset = 0;

	bitmaps[7].angle = 210;
	bitmaps[7].xOffset = 7;
	bitmaps[7].yOffset = 0;

	bitmaps[8].angle = 240;
	bitmaps[8].xOffset = 8;
	bitmaps[8].yOffset = 0;

	bitmaps[9].angle = 270;
	bitmaps[9].xOffset = 9;
	bitmaps[9].yOffset = 0;

	bitmaps[10].angle = 300;
	bitmaps[10].xOffset = 10;
	bitmaps[10].yOffset = 0;

	bitmaps[11].angle = 330;
	bitmaps[11].xOffset = 11;
	bitmaps[11].yOffset = 0;

	bitmaps[12].angle = 20;
	bitmaps[12].xOffset = 0;
	bitmaps[12].yOffset = 1;

	bitmaps[13].angle = 45;
	bitmaps[13].xOffset = 1;
	bitmaps[13].yOffset = 1;

	bitmaps[14].angle = 70;
	bitmaps[14].xOffset = 2;
	bitmaps[14].yOffset = 1;

	bitmaps[15].angle = 110;
	bitmaps[15].xOffset = 3;
	bitmaps[15].yOffset = 1;

	bitmaps[16].angle = 135;
	bitmaps[16].xOffset = 4;
	bitmaps[16].yOffset = 1;

	bitmaps[17].angle = 160;
	bitmaps[17].xOffset = 5;
	bitmaps[17].yOffset = 1;

	bitmaps[18].angle = 200;
	bitmaps[18].xOffset = 6;
	bitmaps[18].yOffset = 1;

	bitmaps[19].angle = 225;
	bitmaps[19].xOffset = 7;
	bitmaps[19].yOffset = 1;

	bitmaps[20].angle = 250;
	bitmaps[20].xOffset = 8;
	bitmaps[20].yOffset = 1;

	bitmaps[21].angle = 290;
	bitmaps[21].xOffset = 9;
	bitmaps[21].yOffset = 1;

	bitmaps[22].angle = 315;
	bitmaps[22].xOffset = 10;
	bitmaps[22].yOffset = 1;

	bitmaps[23].angle = 340;
	bitmaps[23].xOffset = 11;
	bitmaps[23].yOffset = 1;
}

RotationalSwitch::~RotationalSwitch() {
	if (pswitchrot)
		delete pswitchrot;
	DeletePositions();
}

void RotationalSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultValue) {
	
	name = n;
	SetValue(defaultValue);
	scnh.RegisterSwitch(this);
}

void RotationalSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row) {

	x = xp;
	y = yp;
	width = w;
	height = h;

	switchSurface = surf;
	switchBorder = bsurf;
	
	row.AddSwitch(this);
	switchRow = &row;

	if (!sclick.isValid()) {
		row.panelSwitches->soundlib->LoadSound(sclick, ROTARY_SOUND, INTERNAL_ONLY);
	}

	OurVessel = switchRow->panelSwitches->vessel;
}

void RotationalSwitch::AddPosition(int value, double angle) {

	RotationalSwitchPosition *p = new RotationalSwitchPosition(value, angle);
	p->SetNext(positionList);
	positionList = p;
	maxState++;

	if (position == 0) {
		position = p;
	}
}

void RotationalSwitch::DeletePositions() {

	RotationalSwitchPosition *p1, *p = positionList; 
	while (p) {
		p1 = p->GetNext();
		delete p;
		p = p1;
	}

	position = 0;
	positionList = 0;
}

void RotationalSwitch::DrawSwitch(SURFHANDLE drawSurface) {

	if (position) {
		// Find best bitmap for position angle
		int index = -1;
		for (int i = 0; i < RotationalSwitchBitmapCount; i++) {
			if (index == -1) {
				index = i;
			} else if (AngleDiff(bitmaps[i].angle, position->GetAngle()) < AngleDiff(bitmaps[index].angle, position->GetAngle())) {
				index = i;
			}
		}
		oapiBlt(drawSurface, switchSurface, x, y, bitmaps[index].xOffset * width, bitmaps[index].yOffset * height, width, height, SURF_PREDEF_CK);
	}
}

void RotationalSwitch::DrawFlash(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;

	if (switchBorder)
		oapiBlt(DrawSurface, switchBorder, x, y, 0, 0, width, height, SURF_PREDEF_CK);
}

bool RotationalSwitch::CheckMouseClick(int event, int mx, int my) {

	// Check whether it's actually in our switch region.
	if (mx < x || my < y)
		return false;

	if (mx > (x + width) || my > (y + height))
		return false;

	int state = GetState();

	if (event == PANEL_MOUSE_LBDOWN) {
		if (state > 0) {
			SwitchTo(state - 1);
		}
		else if (state == 0 && Wraparound) {
			SwitchTo(maxState);
		}
	}
	else if (event == PANEL_MOUSE_RBDOWN) {
		if (state < maxState) {
			SwitchTo(state + 1);
		}
		else if (state == maxState && Wraparound) {
			SwitchTo(0);
		}
	}
	return true;
}

bool RotationalSwitch::SwitchTo(int newValue) {

	if (!position || (position->GetValue() != newValue)) {
		SetValue(newValue);
		if (soundEnabled) sclick.play();
		if (switchRow) {
			if (switchRow->panelSwitches->listener) 
				switchRow->panelSwitches->listener->PanelRotationalSwitchChanged(this);
		}
		if (callback)
			callback->call(this);
		return true;
	}
	return false;
}

void RotationalSwitch::SetValue(int newValue) { 
	
	RotationalSwitchPosition *p = positionList; 
	while (p) {
		if (p->GetValue() == newValue) {
			position = p;
		}
		p = p->GetNext();
	}
}

double RotationalSwitch::AngleDiff(double a1, double a2) {

	double diff = fabs(a1 - a2);
	if (diff > 180.0) diff = 360.0 - diff;
	return diff;
}

RotationalSwitch::operator int() {

	if (position) {
		return position->GetValue();
	} else {	
		return 0;
	}
}

int RotationalSwitch::GetState() {

	if (position) {
		return position->GetValue();
	} else {	
		return 0;
	}
}

void RotationalSwitch::SaveState(FILEHANDLE scn) {

	if (position) {
		oapiWriteScenario_int (scn, name, position->GetValue()); 
	}		
}

void RotationalSwitch::LoadState(char *line) {

	char buffer[100];
	int val;

	sscanf(line, "%s %i", buffer, &val); 
	if (!strnicmp(buffer, name, strlen(name))) {
		SetValue(val);
	}
}

void RotationalSwitch::SetState(int value)
{
	SwitchTo(value);
}

void RotationalSwitch::DefineMeshGroup(UINT _grpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
}

void RotationalSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), GetDirection(), (float)(RAD * 360));
		anim_switch = OurVessel->CreateAnimation(0.0);
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void RotationalSwitch::DrawSwitchVC(int id, int event, SURFHANDLE drawSurface)
{
	if (!bHasAnimations) return;

	double state = 0;

	if (position) state = position->GetAngle();

	OurVessel->SetAnimation(anim_switch, state / 360);
}

bool RotationalSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	int state = GetState();

	if (event == PANEL_MOUSE_LBDOWN) {
		if (state > 0) {
			SwitchTo(state - 1);
		}
		else if (state == 0 && Wraparound) {
			SwitchTo(maxState);
		}
	}
	else if (event == PANEL_MOUSE_RBDOWN) {
		if (state < maxState) {
			SwitchTo(state + 1);
		}
		else if (state == maxState && Wraparound) {
			SwitchTo(0);
		}
	}
	return true;
}

RotationalSwitchPosition::RotationalSwitchPosition(int v, double a) {

	value = v;
	angle = a;
}

RotationalSwitchPosition::~RotationalSwitchPosition() {
}

PowerStateRotationalSwitch::PowerStateRotationalSwitch()

{
	int i;

	for (i = 0; i < 16; i++)
		sources[i] = 0;
}

void PowerStateRotationalSwitch::CheckPowerState()

{
	WireTo(sources[GetState()]);
}

double PowerStateRotationalSwitch::Current()

{
	e_object *e = sources[GetState()];
	if (e)
	{
		return e->Current();
	}

	return 0.0;
}

double PowerStateRotationalSwitch::Voltage()

{
	e_object *e = sources[GetState()];
	if (e)
	{
		return e->Voltage();
	}

	return 0.0;
}

/*bool PowerStateRotationalSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (RotationalSwitch::CheckMouseClick(event, mx, my)) {
		CheckPowerState();
		return true;
	}

	return false;
}*/

void PowerStateRotationalSwitch::SetSource(int num, e_object *s)

{
	if (num >= 0 && num < 16)
		sources[num] = s; 

	CheckPowerState();
}

bool PowerStateRotationalSwitch::SwitchTo(int newValue)

{
	if (RotationalSwitch::SwitchTo(newValue)) {
		CheckPowerState();
		return true;
	}

	return false;
}

void PowerStateRotationalSwitch::LoadState(char *line)

{
	RotationalSwitch::LoadState(line);
	CheckPowerState();
}

void OrdealRotationalSwitch::DrawSwitch(SURFHANDLE drawSurface) {

	ContinuousRotationalSwitch::DrawSwitch(drawSurface);

	if (mouseDown) {
		RECT rt;
		double value;
		int rotstate;
		char label[100];
		value = GetValue();
		sprintf(label, "%.0lf", value);
		rotstate = (int)(value*19.0 / 600.0 - 0.25); //31.57894736842105

		oapi::Sketchpad* skp = oapiGetSketchpad(drawSurface);
		oapi::Font* font = oapiCreateFont(22, true, "Arial", FONT_BOLD);
		oapi::Brush* brush = oapiCreateBrush(RGB(146, 146, 146));
		oapi::Pen* pen = oapiCreatePen(1, 1, RGB(146, 146, 146));
		skp->SetBrush(brush);
		skp->SetPen(pen);
		skp->SetFont(font);
		skp->SetTextColor(RGB(255, 255, 255));
		skp->SetTextAlign(oapi::Sketchpad::CENTER);
		skp->SetBackgroundMode(oapi::Sketchpad::BK_OPAQUE);
		skp->SetBackgroundColor(RGB(146, 146, 146));

		switch (rotstate)
		{
		case 0: //-120�
			rt.left = 29 + x;
			rt.top = 24 + y;
			rt.right = 60 + x;
			rt.bottom = 55 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(44 + x, 28 + y, label, strlen(label));
			break;
		case 1: //-90�
			rt.left = 35 + x;
			rt.top = 30 + y;
			rt.right = 59 + x;
			rt.bottom = 52 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(49 + x, 31 + y, label, strlen(label));
			break;
		case 2: //-60�
			rt.left = 32 + x;
			rt.top = 29 + y;
			rt.right = 63 + x;
			rt.bottom = 59 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(47 + x, 34 + y, label, strlen(label));
			break;
		case 3: //-30�
			rt.left = 29 + x;
			rt.top = 29 + y;
			rt.right = 60 + x;
			rt.bottom = 59 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(44 + x, 34 + y, label, strlen(label));
			break;
		case 4: //0�
			rt.left = 29 + x;
			rt.top = 35 + y;
			rt.right = 57 + x;
			rt.bottom = 59 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(42 + x, 36 + y, label, strlen(label));
			break;
		case 5: //30�
		case 6: //60�
			rt.left = 28 + x;
			rt.top = 30 + y;
			rt.right = 54 + x;
			rt.bottom = 60 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(37 + x, 34 + y, label, strlen(label));
			break;
		case 7: //90�
			skp->Text(32 + x, 31 + y, label, strlen(label));
			break;
		case 8: //120�
		case 9: //150�
			rt.left = 25 + x;
			rt.top = 24 + y;
			rt.right = 55 + x;
			rt.bottom = 54 + y;
			skp->Rectangle(rt.left, rt.top, rt.right, rt.bottom);
			skp->Text(39 + x, 28 + y, label, strlen(label));
			break;
		}

		oapiReleaseFont(font);
		oapiReleaseBrush(brush);
		oapiReleasePen(pen);
		oapiReleaseSketchpad(skp);
	}
}

//
// Thumbwheel Switch
//

ThumbwheelSwitch::ThumbwheelSwitch() {

	x = 0;
	y = 0;
	width = 0;
	height = 0;
	state = 0;
	maxState = 0;
	switchSurface = 0;
	switchRow = 0;
	OurVessel = 0;
	pswitchrot = NULL;
	grpIndex = 0;
	anim_switch = 0;

	RotationRange = RAD * 324;
}

ThumbwheelSwitch::~ThumbwheelSwitch() {
	if (pswitchrot)
		delete pswitchrot;
}

void ThumbwheelSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, int maximumState) {

	Register(scnh, n, defaultState, maximumState, false);
}

void ThumbwheelSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState, int maximumState, bool horizontal) {

	name = n;
	state = defaultState;
	maxState = maximumState;
	isHorizontal = horizontal;
	scnh.RegisterSwitch(this);
}

void ThumbwheelSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row) {

	x = xp;
	y = yp;
	width = w;
	height = h;
	switchSurface = surf;
	switchBorder = bsurf;
	
	row.AddSwitch(this);
	switchRow = &row;

	if (!sclick.isValid()) {
		row.panelSwitches->soundlib->LoadSound(sclick, THUMBWHEEL_SOUND, INTERNAL_ONLY);
	}

	OurVessel = switchRow->panelSwitches->vessel;
}

int ThumbwheelSwitch::GetState() {

	return state;
}

bool ThumbwheelSwitch::CheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	//
	// Check whether it's actually in our switch region.
	//

	if (mx < x || my < y)
		return false;

	if (mx > (x + width) || my > (y + height))
		return false;

	//
	// Yes, so now we just need to check whether it's an on or
	// off click.
	//

	if (event == PANEL_MOUSE_LBDOWN) {
		if (isHorizontal) {
			if (mx < (x + (width / 2.0))) {
				if (state < maxState) {
					SwitchTo(state + 1);
					sclick.play();
				}
			}
			else {
				if (state > 0) {
					SwitchTo(state - 1);
					sclick.play();
				}
			}
		} else {
			if (my < (y + (height / 2.0))) {
				if (state < maxState) {
					SwitchTo(state + 1);
					sclick.play();
				}
			}
			else {
				if (state > 0) {
					SwitchTo(state - 1);
					sclick.play();
				}
			}
		}
	}

	return true;
}

void ThumbwheelSwitch::SetRotationRange(const double range)
{
	RotationRange = range;
}

const double ThumbwheelSwitch::GetRotationRange() const
{
	return RotationRange;
}

void ThumbwheelSwitch::DefineMeshGroup(UINT _grpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
}

void ThumbwheelSwitch::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasDirection && bHasMeshGroup && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), GetDirection(), (float)(GetRotationRange()));
		anim_switch = OurVessel->CreateAnimation(InitialAnimState());
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

bool ThumbwheelSwitch::CheckMouseClickVC(int event, VECTOR3 &p) {

	if (event == PANEL_MOUSE_LBDOWN) {
		if (state < maxState) {
			SwitchTo(state + 1);
			sclick.play();
		}
	}
	else {
		if (state > 0) {
			SwitchTo(state - 1);
			sclick.play();
		}
	}

	return true;
}

bool ThumbwheelSwitch::SwitchTo(int newState) {

	if (newState >= 0 && newState <= maxState && state != newState) {
		state = newState;
		sclick.play();
		if (callback)
			callback->call(this);
		return true;
	}
	return false;
}

void ThumbwheelSwitch::DrawSwitch(SURFHANDLE DrawSurface) {

	oapiBlt(DrawSurface, switchSurface, x, y, state * width, 0, width, height, SURF_PREDEF_CK);
}

void ThumbwheelSwitch::DrawSwitchVC(int id, int event, SURFHANDLE drawSurface) {

	double s = ((double)state) / ((double)maxState);
	OurVessel->SetAnimation(anim_switch, s);
}

void ThumbwheelSwitch::DrawFlash(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;

	if (switchBorder)
		oapiBlt(DrawSurface, switchBorder, x, y, 0, 0, width, height, SURF_PREDEF_CK);
}

void ThumbwheelSwitch::SaveState(FILEHANDLE scn) {

	oapiWriteScenario_int (scn, name, state);
}

void ThumbwheelSwitch::LoadState(char *line) {

	char buffer[100];
	int st;

	sscanf(line, "%s %i", buffer, &st); 
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
	}
}

void ThumbwheelSwitch::SetState(int value)
{
	SwitchTo(value);
}

//
// Thumbwheel which adjusts volume levels.
//

VolumeThumbwheelSwitch::VolumeThumbwheelSwitch()

{
	sl = 0;
	volume_class = -1;
}

void VolumeThumbwheelSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, int vclass, SoundLib *s)

{
	ThumbwheelSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	sl = s;
	volume_class = vclass;

	if (sl) {
		sl->SetVolume(volume_class, (int) (state * (100.0 / 9.0)));
	}
}

//
// We override CheckMouseClick so we can update the volume on change.
//

bool VolumeThumbwheelSwitch::SwitchTo(int newState)

{
	bool ret = ThumbwheelSwitch::SwitchTo(newState);

	if (ret && sl) {
		sl->SetVolume(volume_class, (int) (state * (100.0 / 9.0)));
	}

	return ret;
}

//
// We override LoadState() so we can update the volume on loading.
//

void VolumeThumbwheelSwitch::LoadState(char *line)

{
	ThumbwheelSwitch::LoadState(line);

	if (sl) {
		sl->SetVolume(volume_class, (int) (state * (100.0 / 9.0)));
	}
}

//
// Indicator Switch
//

IndicatorSwitch::IndicatorSwitch() {

	state = false;
	displayState = 0.0;
	failOpen = false;
	x = 0;
	y = 0;
	width = 0;
	height = 0;
	switchSurface = 0;
	switchRow = 0;
	SRC = NULL;

}

IndicatorSwitch::~IndicatorSwitch() {
}

void IndicatorSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, int defaultState) {

	name = n;
	state = defaultState;
	if (state) 
		displayState = 3.0;
	else
		displayState = 0.0;

	scnh.RegisterSwitch(this);
}

void IndicatorSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SwitchRow &row, bool failopen) {

	x = xp;
	y = yp;
	width = w;
	height = h;
	switchSurface = surf;
	failOpen = failopen;
	
	row.AddSwitch(this);
	switchRow = &row;
}

bool IndicatorSwitch::CheckMouseClick(int event, int mx, int my) {

	return false;
}

void IndicatorSwitch::DrawSwitch(SURFHANDLE drawSurface) {

	int drawState=0;
	if (switchRow) {
		if (switchRow->panelSwitches->listener) 
			switchRow->panelSwitches->listener->PanelIndicatorSwitchStateRequested(this);
	}
	if (callback)
		callback->call(this);

	// Require power if wired
	if (SRC != NULL) {
		if (SRC->Voltage() > SP_MIN_DCVOLTAGE) {
			drawState = GetState();
		} else {
			drawState = (failOpen ? 1 : 0);
		}
	} else {
		drawState = GetState();
	}

	if (drawState && displayState < 3.0)
		displayState += oapiGetSimStep() * 4.0;

	if (!drawState && displayState > 0.0) 
		displayState -= oapiGetSimStep() * 4.0;

	if (displayState > 3.0) displayState = 3.0;
	if (displayState < 0.0) displayState = 0.0;

	// Cheating beyond normal saves switch subclasses and associated etcetera
	if (displayState == 3.0 && drawState > 1) {
		displayState += (drawState - 1);
	}

	oapiBlt(drawSurface, switchSurface, x, y, width * (int) displayState, 0, width, height);
}

void IndicatorSwitch::InitVC(SURFHANDLE surf)
{
	switchsurfacevc = surf;
}

void IndicatorSwitch::DrawSwitchVC(int id, int event, SURFHANDLE drawSurface) {

	int drawState = 0;
	if (switchRow) {
		if (switchRow->panelSwitches->listener)
			switchRow->panelSwitches->listener->PanelIndicatorSwitchStateRequested(this);
	}
	if (callback)
		callback->call(this);

	// Require power if wired
	if (SRC != NULL) {
		if (SRC->Voltage() > SP_MIN_DCVOLTAGE) {
			drawState = GetState();
		}
		else {
			drawState = (failOpen ? 1 : 0);
		}
	}
	else {
		drawState = GetState();
	}

	if (drawState && displayState < 3.0)
		displayState += oapiGetSimStep() * 64.0;

	if (!drawState && displayState > 0.0)
		displayState -= oapiGetSimStep() * 64.0;

	if (displayState > 3.0) displayState = 3.0;
	if (displayState < 0.0) displayState = 0.0;

	// Cheating beyond normal saves switch subclasses and associated etcetera
	if (displayState == 3.0 && drawState > 1) {
		displayState += (drawState - 1);
	}

	oapiBlt(drawSurface, switchsurfacevc, x*TexMul, y*TexMul, width * (int)displayState*TexMul, 0, width*TexMul, height*TexMul);
}

void IndicatorSwitch::SaveState(FILEHANDLE scn) {

	oapiWriteScenario_int (scn, name, state); 
}

void IndicatorSwitch::LoadState(char *line) {

	char buffer[100];
	int st = FALSE; // Avoids crash bug

	sscanf(line, "%s %i", buffer, &st); 
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
		if (state != 0){
			displayState = 3.0;
		}else{
			displayState = 0.0;
		}
		// Cheating beyond normal saves switch subclasses and associated etcetera
		if (displayState == 3.0 && state > 1){
			displayState += (state - 1);
		}
	}
}


//
// Meter Switch
//

MeterSwitch::MeterSwitch() {

	value = 0;
	displayValue = 0;
	minValue = 0;
	maxValue = 0;
	switchRow = 0;
	lastDrawTime = -1;

	grpIndex = 0;
	anim_switch = 0;
}

MeterSwitch::~MeterSwitch() {
}

void MeterSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, double min, double max, double time) {

	Register(scnh, n, min, max, time, min);
}

void MeterSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, double min, double max, double time, double defaultValue) {

	name = n;
	value = defaultValue;
	displayValue = defaultValue;
	minValue = min;
	maxValue = max;
	minMaxTime = time;
	scnh.RegisterSwitch(this);
}

void MeterSwitch::Init(SwitchRow &row) {

	row.AddSwitch(this);
	switchRow = &row;

	OurVessel = switchRow->panelSwitches->vessel;
}

void MeterSwitch::DefineMeshGroup(UINT _grpIndex)
{
	bHasMeshGroup = true;
	grpIndex = _grpIndex;
}

bool MeterSwitch::CheckMouseClick(int event, int mx, int my) {

	return false;
}

void MeterSwitch::DrawSwitch(SURFHANDLE drawSurface) {

	DoDrawSwitch(GetDisplayValue(), drawSurface);
}

double MeterSwitch::GetDisplayValue() {

	// Prevent problems if the simulation is started paused and 
	// a lot of values are zero in that case
	if (oapiGetPause())
		return displayValue;

	if (lastDrawTime == -1) {
		lastDrawTime = oapiGetSimTime(); // oapiGetSimTime();
		return displayValue;
	}

	value = AdjustForPower(QueryValue());
	if (value > maxValue) value = maxValue;
	if (value < minValue) value = minValue;

	if (minMaxTime == 0) {
		displayValue = value;
	} else {
		double dt = oapiGetSimTime() - lastDrawTime; // oapiGetSimTime() - lastDrawTime;
		if (dt > 0.0) {
			// discrete time LPF where y[n] = y[n-1]*(1-a) + x[n]*a
			// assumed that 5tau is minMaxTime, i.e. time to reach 99.3% of a step input.
			// therefore 1/tau is (5/minMaxTime) for each slice {dt}.
			double filtConstant = max(min(GAUGE_LPF_SCALAR * dt * 5.0 / minMaxTime, 1.0), 0.0);
			displayValue = displayValue * (1.0 - filtConstant) + (value * filtConstant);
		}
	}
	lastDrawTime = oapiGetSimTime(); // oapiGetSimTime();
	return displayValue;
}

//
// Adjust the input value based on the voltage fed to the meter.
// CWS limit for main bus undervolt is 26.25 V, so we begin at 26 V 
// with the adjustment
//

double MeterSwitch::AdjustForPower(double val)

{
	double volts = Voltage();

	if (volts >= 26.0)
		return val;

	if (volts == 0)      // Hack to make meters with minimums below zero show properly
		return minValue; // when the power is out. DS20100509

	// sprintf(oapiDebugString(), "MeterSwitch::AdjustForPower %s undervolt", name);
	return ((val * (volts - 1.0)) / 25.0);
}

void MeterSwitch::SaveState(FILEHANDLE scn) {

	char buffer[100];

	sprintf(buffer, "%lf %lf", value, displayValue); 
	oapiWriteScenario_string(scn, name, buffer);
}

void MeterSwitch::LoadState(char *line) {

	char buffer[100];
	double v, dv;

	sscanf(line, "%s %lf %lf", buffer, &v, &dv); 
	if (!strnicmp(buffer, name, strlen(name))) {
		value = v;
		displayValue = dv;
	}
}

CurvedMeter::CurvedMeter()
{
	pswitchrot = NULL;
	RotationRange = RAD * 34;
}

CurvedMeter::~CurvedMeter()
{
	if (pswitchrot)
		delete pswitchrot;
}

void CurvedMeter::SetRotationRange(const double range)
{
	RotationRange = range;
}

const double CurvedMeter::GetRotationRange() const
{
	return RotationRange;
}

void CurvedMeter::DefineVCAnimations(UINT vc_idx)
{
	if (bHasReference && bHasMeshGroup && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), _V(1, 0, 0), (float)(GetRotationRange()));
		anim_switch = OurVessel->CreateAnimation(0.0);
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void CurvedMeter::OnPostStep(double SimT, double DeltaT, double MJD)
{
	double v = (GetDisplayValue() - minValue) / (maxValue - minValue);
	OurVessel->SetAnimation(anim_switch, v);
}

LinearMeter::LinearMeter()
{
	pswitchtrans = NULL;
}

LinearMeter::~LinearMeter()
{
	if (pswitchtrans)
		delete pswitchtrans;
}

void LinearMeter::DefineVCAnimations(UINT vc_idx)
{
	if (bHasDirection && !bHasAnimations)
	{
		pswitchtrans = new MGROUP_TRANSLATE(vc_idx, &grpIndex, 1, GetDirection());
		anim_switch = OurVessel->CreateAnimation(0.0);
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchtrans);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void LinearMeter::OnPostStep(double SimT, double DeltaT, double MJD)
{
	double v = (GetDisplayValue() - minValue) / (maxValue - minValue);
	OurVessel->SetAnimation(anim_switch, v);
}

RoundMeter::RoundMeter()
{
	pswitchrot = NULL;
	RotationRange = RAD * 270;
	fInitialAnimState = 0.5;
}

RoundMeter::~RoundMeter()
{
	if (pswitchrot)
		delete pswitchrot;
}

void RoundMeter::Init(oapi::Pen *p0, oapi::Pen *p1, SwitchRow &row)

{
	MeterSwitch::Init(row);
	Pen0 = p0;
	Pen1 = p1;
}

void RoundMeter::SetRotationRange(const double range)
{
	RotationRange = range;
}

const double RoundMeter::GetRotationRange() const
{
	return RotationRange;
}

void RoundMeter::DefineVCAnimations(UINT vc_idx)
{
	if (bHasDirection && bHasReference && !bHasAnimations)
	{
		pswitchrot = new MGROUP_ROTATE(vc_idx, &grpIndex, 1, GetReference(), GetDirection(), (float)(GetRotationRange()));
		anim_switch = OurVessel->CreateAnimation(InitialAnimState());
		OurVessel->AddAnimationComponent(anim_switch, 0.0f, 1.0f, pswitchrot);
		VerifyAnimations();
	}
	/*
	else
	{
		char Buff[128];
		sprintf(Buff, "Could not create animation for %s. bRef %d bDir %d bMesh %d", name, bHasReference, bHasDirection, bHasMeshGroup);
		oapiWriteLog(Buff);
	}
	*/
}

void RoundMeter::OnPostStep(double SimT, double DeltaT, double MJD)
{
	double v = (GetDisplayValue() - minValue) / (maxValue - minValue);
	OurVessel->SetAnimation(anim_switch, v);
}

void RoundMeter::DrawNeedle (SURFHANDLE surf, int x, int y, double rad, double angle)
{
	// Needle function by Rob Conley from Mercury code
	// Drawn from center of rotation to "rad" distance
	
	double dx = rad * cos(angle), dy = rad * sin(angle);

	oapi::Sketchpad* skp = oapiGetSketchpad(surf);
	skp->SetPen(Pen1);
	skp->MoveTo(x, y); skp->LineTo(x + (int)(0.85 * dx + 0.5), y - (int)(0.85 * dy + 0.5));
	skp->SetPen(Pen0);
	skp->MoveTo(x, y); skp->LineTo(x + (int)(dx + 0.5), y - (int)(dy + 0.5));
	oapiReleaseSketchpad(skp);
}

void RoundMeter::DrawNeedle2(SURFHANDLE surf, int x, int y, double rad_1, double rad_2, double angle)
{
	// Drawn from center of rotation to "rad_1" distance in one direction, "rad_2" in the other direction
	// If rad_1 and rad_2 are set identical then the needle is centered on the axis of rotation

	double dx1 = -rad_1 * cos(angle), dy1 = -rad_1 * sin(angle);
	double dx2 = rad_2 * cos(angle), dy2 = rad_2 * sin(angle);

	oapi::Sketchpad* skp = oapiGetSketchpad(surf);
	skp->SetPen(Pen0);
	skp->Line(x + (int)(dx1 + 0.5), y - (int)(dy1 + 0.5), x + (int)(dx2 + 0.5), y - (int)(dy2 + 0.5));
	oapiReleaseSketchpad(skp);
}

ElectricMeter::ElectricMeter(double minVal, double maxVal, double vMin, double vMax)

{
	minValue = minVal;
	maxValue = maxVal;
	minAngle = vMin;
	maxAngle = vMax;

	xSize = 99;
	ySize = 98;

	ScaleFactor = (vMax - vMin) / (maxValue - minValue);
}

void ElectricMeter::SetSurface(SURFHANDLE srf, int x, int y)

{
	xSize = x;
	ySize = y;
	FrameSurface = srf;
}

void ElectricMeter::Init(oapi::Pen *p0, oapi::Pen *p1, SwitchRow &row, e_object *dcindicatorswitch)

{
	RoundMeter::Init(p0, p1, row);
	WireTo(dcindicatorswitch);
}

void ElectricMeter::DoDrawSwitch(double volts, SURFHANDLE drawSurface)

{
	double v = minAngle + (ScaleFactor * (volts - minValue));
	DrawNeedle(drawSurface, xSize / 2, ySize / 2, 25.0, v * RAD);
	oapiBlt(drawSurface, FrameSurface, 0, 0, 0, 0, xSize, ySize, SURF_PREDEF_CK);

	//angle debug lines
	//if (strcmp(name, "DCAmpMeter") == 0)
	//{
	//	sprintf(oapiDebugString(), "Angle %lf Current %.2f", 90.0 - v, volts);
	//}
}

DCVoltMeter::DCVoltMeter(double minVal, double maxVal, double vMin, double vMax) :
	ElectricMeter(minVal, maxVal, vMin, vMax)

{
}

double DCVoltMeter::QueryValue()

{
	return Voltage();
}

ACVoltMeter::ACVoltMeter(double minVal, double maxVal, double vMin, double vMax) :
	ElectricMeter(minVal, maxVal, vMin, vMax)

{
}

double ACVoltMeter::QueryValue()

{
	return Voltage();
}

DCAmpMeter::DCAmpMeter(double minVal, double maxVal, double vMin, double vMax) :
	ElectricMeter(minVal, maxVal, vMin, vMax)

{
}

double DCAmpMeter::QueryValue()

{
	if (SRC)
	{
		return SRC->Current();
	}

	return 0.0;
}

//
// Panel Switch Scenario Handler
//

void PanelSwitchScenarioHandler::RegisterSwitch(PanelSwitchItem *s) {

	s->SetNextForScenario(switchList); 
	switchList = s; 
}

void PanelSwitchScenarioHandler::SaveState(FILEHANDLE scn) {

	oapiWriteLine(scn, PANELSWITCH_START_STRING);

 	PanelSwitchItem *s = switchList;
	while (s) {
		s->SaveState(scn);
		s = s->GetNextForScenario();
	}

	oapiWriteLine(scn, PANELSWITCH_END_STRING);
}

void PanelSwitchScenarioHandler::LoadState(FILEHANDLE scn) {

	char * line;

	while (oapiReadScenario_nextline (scn, line)) {
		if (!strnicmp(line, PANELSWITCH_END_STRING, strlen(PANELSWITCH_END_STRING)))
			return;

		PanelSwitchItem *s = switchList;
		while (s) {
			s->LoadState(line);
			s = s->GetNextForScenario();
		}
	}
}

PanelSwitchItem* PanelSwitchScenarioHandler::GetSwitch(char *name) {

	PanelSwitchItem *s = switchList;
	while (s) {
		if (!stricmp(s->GetName(), name)) 
			return s;
		s = s->GetNextForScenario();
	}
	return 0;
}


void MissionTimerSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, MissionTimer *ptimer)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	timer = ptimer;
}

//
// ThreeSourceSwitch allows you to connect the output to one of three inputs based on the position
// of the switch.
//

void ThreeSourceSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
}

void ThreeSourceSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *s1, e_object *s2, e_object *s3)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	source[0] = s1;
	source[1] = s2;
	source[2] = s3;

	UpdateSourceState();
}

/*bool ThreeSourceSwitch::CheckMouseClick(int event, int mx, int my)
{
	if (ThreePosSwitch::CheckMouseClick(event, mx, my))
	{
		UpdateSourceState();
		return true;
	}

	return false;
}*/

bool ThreeSourceSwitch::SwitchTo(int newState, bool dontspring)

{
	if (ThreePosSwitch::SwitchTo(newState,dontspring)) {
		UpdateSourceState();
		return true;
	}
	return false;
}

void ThreeSourceSwitch::UpdateSourceState()

{
	if (IsUp()) {
		WireTo(source[0]);
	}
	else if (IsCenter()) {
		WireTo(source[1]);
	}
	else if (IsDown()) {
		WireTo(source[2]);
	}
}

void ThreeSourceSwitch::LoadState(char *line)

{
	ThreePosSwitch::LoadState(line);
	UpdateSourceState();
}

void ThreeSourceSwitch::SetSource(int i, e_object *s)
{
	source[i] = s;

	UpdateSourceState();
}

/*void ThreeSourceSwitch::SetState(int value)
{
	SwitchTo(value);
}*/


//
// TwoSourceSwitch allows you to connect the output to one of two inputs based on the position
// of the switch.
//

void TwoSourceSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *s1, e_object *s2)

{
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	source1 = s1;
	source2 = s2;

	UpdateSourceState();
}

/*bool TwoSourceSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (ToggleSwitch::CheckMouseClick(event, mx, my))
	{
		UpdateSourceState();
		return true;
	}

	return false;
}*/

bool TwoSourceSwitch::SwitchTo(int newState, bool dontspring)

{
	if (ToggleSwitch::SwitchTo(newState,dontspring)) {
		UpdateSourceState();
		return true;
	}
	return false;
}

void TwoSourceSwitch::UpdateSourceState()

{
	if (IsUp()) {
		WireTo(source1);
	}
	else if (IsDown()) {
		WireTo(source2);
	}
}

void TwoSourceSwitch::LoadState(char *line)

{
	ToggleSwitch::LoadState(line);
	UpdateSourceState();
}

/*void TwoSourceSwitch::SetState(int value)
{
	SwitchTo(value);
}*/

//
// GuardedTwoSourceSwitch allows you to connect the output to one of two inputs based on the position
// of the switch.
//

void GuardedTwoSourceSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *s1, e_object *s2)

{
	GuardedToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	source1 = s1;
	source2 = s2;

	UpdateSourceState();
}

/*bool GuardedTwoSourceSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (GuardedToggleSwitch::CheckMouseClick(event, mx, my))
	{
		UpdateSourceState();
		return true;
	}

	return false;
}*/

bool GuardedTwoSourceSwitch::SwitchTo(int newState, bool dontspring)

{
	if (GuardedToggleSwitch::SwitchTo(newState, dontspring)) {
		UpdateSourceState();
		return true;
	}
	return false;
}

void GuardedTwoSourceSwitch::UpdateSourceState()

{
	if (IsUp()) {
		WireTo(source1);
	}
	else if (IsDown()) {
		WireTo(source2);
	}
}

void GuardedTwoSourceSwitch::LoadState(char *line)

{
	GuardedToggleSwitch::LoadState(line);
	UpdateSourceState();
}
//
// TwoOutputSwitch allows you to connect one of the two outputs to the input based on the position
// of the switch.
//

void TwoOutputSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *o1, e_object *o2)

{
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	output1 = o1;
	output2 = o2;

	UpdateSourceState();
}

/*bool TwoOutputSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (ToggleSwitch::CheckMouseClick(event, mx, my))
	{
		UpdateSourceState();
		return true;
	}

	return false;
}*/

bool TwoOutputSwitch::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState,dontspring))
	{
		UpdateSourceState();
		return true;
	}
	return false;
}

void TwoOutputSwitch::UpdateSourceState()

{
	if (IsUp()) {
		if (output1)
			output1->WireTo(this);
		if (output2)
			output2->WireTo(0);
	}
	else if (IsDown()) {
		if (output1)
			output1->WireTo(0);
		if (output2)
			output2->WireTo(this);
	}
}

void TwoOutputSwitch::LoadState(char *line)

{
	ToggleSwitch::LoadState(line);
	UpdateSourceState();
}


NSourceDestSwitch::NSourceDestSwitch(int n)
{
	nSources = n;
	sources = new e_object *[nSources];
	buses = new DCbus *[nSources];

	int i;

	for (i = 0; i < nSources; i++)
	{
		sources[i] = 0;
		buses[i] = 0;
	}
}

NSourceDestSwitch::~NSourceDestSwitch()
{
	if (sources)
	{
		delete[] sources;
		sources = 0;
	}
	if (buses)
	{
		delete[] buses;
		buses = 0;
	}
}

void NSourceDestSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row)
{
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);

	UpdateSourceState();
}

bool NSourceDestSwitch::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState, dontspring))
	{
		UpdateSourceState();
		return true;
	}
	return false;
}

void NSourceDestSwitch::UpdateSourceState()
{
	if (IsUp()) {
		for (int i = 0;i < nSources;i++)
		{
			buses[i]->WireTo(sources[i]);
		}
	}
	else if (IsDown()) {
		for (int i = 0;i < nSources;i++)
		{
			buses[i]->Disconnect();
		}
	}
}

void NSourceDestSwitch::WireSourcesToBuses(int bus, e_object* i, DCbus* o)
{
	if (bus > 0 && bus <= nSources)
	{
		sources[bus - 1] = i;
		buses[bus - 1] = o;
	}
}

void NSourceDestSwitch::LoadState(char *line)
{
	ToggleSwitch::LoadState(line);
	UpdateSourceState();
}

//
// ThreeOutputSwitch allows you to connect one of the three outputs to the input based on the position
// of the switch.
//

void ThreeOutputSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *o1, e_object *o2, e_object *o3)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	output1 = o1;
	output2 = o2;
	output3 = o3;

	UpdateSourceState();
}

/*bool ThreeOutputSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (ThreePosSwitch::CheckMouseClick(event, mx, my))
	{
		UpdateSourceState();
		return true;
	}

	return false;
}*/

void ThreeOutputSwitch::UpdateSourceState()

{
	if (IsUp()) {
		if (output1) output1->WireTo(this);
		if (output2) output2->WireTo(0);
		if (output3) output3->WireTo(0);

	} else if (IsCenter()) {
		if (output1) output1->WireTo(0);
		if (output2) output2->WireTo(this);
		if (output3) output3->WireTo(0);

	} else if (IsDown()) {
		if (output1) output1->WireTo(0);
		if (output2) output2->WireTo(0);
		if (output3) output3->WireTo(this);
	}
}

void ThreeOutputSwitch::LoadState(char *line)

{
	ThreePosSwitch::LoadState(line);
	UpdateSourceState();
}

bool ThreeOutputSwitch::SwitchTo(int newState, bool dontspring)

{
	if (ThreePosSwitch::SwitchTo(newState, dontspring)) {
		UpdateSourceState();
		return true;
	}
	return false;
}

//
// GuardedTwoOutputSwitch allows you to connect one of the two outputs to the input based on the position
// of the switch.
//

void GuardedTwoOutputSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *o1, e_object *o2)

{
	GuardedToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	output1 = o1;
	output2 = o2;

	UpdateSourceState(GetState());
}

/*bool GuardedTwoOutputSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (GuardedToggleSwitch::CheckMouseClick(event, mx, my))
	{
		UpdateSourceState(GetState());
		return true;
	}

	return false;
}*/

bool GuardedTwoOutputSwitch::SwitchTo(int newState, bool dontspring)

{
	if (GuardedToggleSwitch::SwitchTo(newState,dontspring))
	{
		// some of these switches are spring-loaded, 
		// so we have to use newState here
		UpdateSourceState(newState);
		return true;
	}

	return false;
}

void GuardedTwoOutputSwitch::UpdateSourceState(int newState)

{
	if (newState == TOGGLESWITCH_UP) {
		if (output1)
			output1->WireTo(this);
		if (output2)
			output2->WireTo(0);
	}
	else if (newState == TOGGLESWITCH_DOWN) {
		if (output1)
			output1->WireTo(0);
		if (output2)
			output2->WireTo(this);
	}
}

void GuardedTwoOutputSwitch::LoadState(char *line)

{
	GuardedToggleSwitch::LoadState(line);
	UpdateSourceState(GetState());
}

void GuardedTwoOutputSwitch::SetState(int value)
{
	SwitchTo(value);
}

TimerUpdateSwitch::TimerUpdateSwitch()

{
	adjust_type = TIME_UPDATE_SECONDS;
	springLoaded = SPRINGLOADEDSWITCH_CENTER;
}

void ThreeSourceTwoDestSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, e_object *s1, e_object *s2, e_object *s3, e_object *d1, e_object *d2)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	source[0] = s1;
	source[1] = s2;
	source[2] = s3;
	dest1 = d1;
	dest2 = d2;

	UpdateSourceState();
}

void ThreeSourceTwoDestSwitch::UpdateSourceState()

{
	if (IsUp()) {
		//
		// Source 1 to dest 1, source 3 to dest 2
		//
		dest1->WireTo(source[0]);
		dest2->WireTo(source[1]);
	}
	else if (IsCenter()) {
		//
		// Disconnect. Center is usually wired to NULL, for an "Off" state
		//
		dest1->WireTo(source[1]);
		dest2->WireTo(source[1]);
	}
	else if (IsDown()) {
		//
		// Source 2 to dest 2, source 3 to dest 1.
		//
		dest1->WireTo(source[1]);
		dest2->WireTo(source[2]);
	}
}

void TimerUpdateSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, int adjuster, MissionTimer *ptimer)

{
	MissionTimerSwitch::Init(xp, yp, w, h, surf, bsurf, row, ptimer);
	adjust_type = adjuster;
}

void TimerUpdateSwitch::AdjustTime(int val)

{
	if (timer) {
		switch (adjust_type) {
		case TIME_UPDATE_HOURS:
			timer->UpdateHours(val);
			break;

		case TIME_UPDATE_MINUTES:
			timer->UpdateMinutes(val);
			break;

		case TIME_UPDATE_SECONDS:
			timer->UpdateSeconds(val);
			break;
		}
	}
}

/*bool TimerControlSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (MissionTimerSwitch::CheckMouseClick(event, mx, my))
	{
		SetTimer();
		return true;
	}

	return false;
}*/

bool TimerControlSwitch::SwitchTo(int newState, bool dontspring) 

{
	if (MissionTimerSwitch::SwitchTo(newState,dontspring)) {
		SetTimer();
		return true;
	}
	return false;
}

void TimerControlSwitch::SetTimer() 

{
	if (timer) {
		if (IsUp()) {
			timer->SetRunning(true);
		}
		else if (IsCenter()) {
			timer->SetRunning(false);
		}
		else if (IsDown()) {
			timer->SetRunning(false);
			timer->Reset();
		}
	}
}


//
// Event timer start/stop switch. Although it's a three-position switch, the center position does
// nothing.
//

bool EventTimerControlSwitch::SwitchTo(int newState, bool dontspring)
{
	if (MissionTimerSwitch::SwitchTo(newState,dontspring))
	{
		if (timer) {
			if (IsUp()) {
				timer->SetRunning(true);
			}
			else if (IsDown()) {
				timer->SetRunning(false);
			}
		}
		return true;
	}
	return false;
}

//
// Event timer up/down/reset switch.
//

bool EventTimerResetSwitch::SwitchTo(int newState, bool dontspring)
{
	if (MissionTimerSwitch::SwitchTo(newState,dontspring))
	{
		if (timer) {
			if (IsUp()) {
				timer->SetCountUp(TIMER_COUNT_NONE);
				timer->Reset();
				timer->SetRunning(false);
			}
			else if (IsCenter()) {
				timer->SetCountUp(TIMER_COUNT_UP);
			}
			else if (IsDown()) {
				timer->SetCountUp(TIMER_COUNT_DOWN);
			}
		}
		return true;
	}
	return false;
}

//
// Generic switch to update the timer time. AdjustTime() knows whether to update the hours, minutes or seconds.
//

/*bool TimerUpdateSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (MissionTimerSwitch::CheckMouseClick(event, mx, my))
	{
		//
		// We need to increase by one if the switch is up, and ten if it's down.
		//
		if (IsUp()) {
			AdjustTime(10);
		}
		else if (IsDown()) {
			AdjustTime(1);
		}
		return true;
	}
	else return false;
}*/

bool TimerUpdateSwitch::SwitchTo(int newstate, bool dontspring)
{
	if (MissionTimerSwitch::SwitchTo(newstate,dontspring))
	{
		//
		// We need to increase by one if the switch is up, and ten if it's down.
		//
		if (IsUp())
		{
			AdjustTime(10);
		}
		else if (IsDown())
		{
			AdjustTime(1);
		}
		return true;
	}
	return false;
}

IMUCageSwitch::IMUCageSwitch()

{
	imu = 0;
}

void IMUCageSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, IMU *im)

{
	GuardedToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	imu = im;
}

/*bool IMUCageSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (GuardedToggleSwitch::CheckMouseClick(event, mx, my))
	{
		SetIMU();
		return true;
	}
	else return false;
}*/

bool IMUCageSwitch::SwitchTo(int newState, bool dontspring)

{
	if (GuardedToggleSwitch::SwitchTo(newState, dontspring))
	{
		SetIMU();
		return true;
	}
	else return false;
}

void IMUCageSwitch::SetIMU() 

{
	//
	// Cage the IMU if it's up, release if it's down. For now we'll also turn it
	// on if the switch is down.
	//
	if (imu) {
		if (IsUp()) {
			imu->SetCaged(true);
		}
		else if (IsDown()) {
			imu->SetCaged(false);
			imu->TurnOn();
		}
	}
}

//
// Unfortunately we need to duplicate this code for the LEM switch which doesn't have a guard.
//

UnguardedIMUCageSwitch::UnguardedIMUCageSwitch()

{
	imu = 0;
}

void UnguardedIMUCageSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, IMU *im)

{
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	imu = im;
}

bool UnguardedIMUCageSwitch::SwitchTo(int newState, bool dontspring)

{
	if (ToggleSwitch::SwitchTo(newState,dontspring))
	{
		SetIMU();
		return true;
	}
	else return false;
}

void UnguardedIMUCageSwitch::SetIMU() 

{
	//
	// Cage the IMU if it's up, release if it's down. For now we'll also turn it
	// on if the switch is down.
	//
	if (imu) {
		if (IsUp()) {
			imu->SetCaged(true);
		}
		else if (IsDown()) {
			imu->SetCaged(false);
			imu->TurnOn();
		}
	}
}

//
// Enable light test on caution and warning system.
//

/*bool CWSLightTestSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (CWSThreePosSwitch::CheckMouseClick(event, mx,my)) {
		//
		// Up lights left-hand lights, down lights right-hand lights.
		//

		if (cws) {
			if (IsUp()) {
				cws->LightTest(CWS_TEST_LIGHTS_LEFT);
			}
			else if (IsDown()) {
				cws->LightTest(CWS_TEST_LIGHTS_RIGHT);
			}
			else if (IsCenter()) {
				cws->LightTest(CWS_TEST_LIGHTS_NONE);
			}
		}
		return true;
	}

	return false;
}*/

bool CWSLightTestSwitch::SwitchTo(int newState, bool dontspring)
{
	if (CWSThreePosSwitch::SwitchTo(newState, dontspring))
	{
		if (cws)
		{
			if (IsUp())
			{
				cws->LightTest(CWS_TEST_LIGHTS_LEFT);
			}
			else if (IsDown())
			{
				cws->LightTest(CWS_TEST_LIGHTS_RIGHT);
			}
			else if (IsCenter())
			{
				cws->LightTest(CWS_TEST_LIGHTS_NONE);
			}
		}
		return true;
	}
	return false;
}
//
// Set caution and warning mode state.
//

/*bool CWSModeSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (CWSThreePosSwitch::CheckMouseClick(event, mx,my)) {
		if (cws) {
			if (IsUp()) {
				cws->SetMode(CWS_MODE_NORMAL);
			}
			else if (IsCenter()) {
				cws->SetMode(CWS_MODE_BOOST);
			}
			else if (IsDown()) {
				cws->SetMode(CWS_MODE_ACK);
			}
		}
		return true;
	}

	return false;
} */

bool CWSModeSwitch::SwitchTo(int newState, bool dontspring) 

{
	if (CWSThreePosSwitch::SwitchTo(newState, dontspring)) {
		if (cws) {
			if (IsUp()) {
				cws->SetMode(CWS_MODE_NORMAL);
			}
			else if (IsCenter()) {
				cws->SetMode(CWS_MODE_BOOST);
			}
			else if (IsDown()) {
				cws->SetMode(CWS_MODE_ACK);
			}
		}
		return true;
	}
	return false;
}


//
// Set caution and warning power source.
//

/*bool CWSPowerSwitch::CheckMouseClick(int event, int mx, int my)

{
	int OldState = state;

	if (CWSThreePosSwitch::CheckMouseClick(event, mx, my)) {
		if (Active && (state != OldState)) {
			SetPowerBus();
		}
		return true;
	}
	return false;
}*/

bool CWSPowerSwitch::SwitchTo(int newState, bool dontspring) 

{
	if (CWSThreePosSwitch::SwitchTo(newState, dontspring)) {
		SetPowerBus();
		return true;
	}
	return false;
}

void CWSPowerSwitch::SetPowerBus() 

{
	if (cws) {
		if (IsUp()) {
			cws->SetPowerBus(CWS_POWER_SUPPLY_1);
		}
		else if (IsCenter()) {
			cws->SetPowerBus(CWS_POWER_NONE);
		}
		else if (IsDown()) {
			cws->SetPowerBus(CWS_POWER_SUPPLY_2);
		}
	}
}

/*void CWSPowerSwitch::SetState(int value)
{
	SwitchTo(value);
}*/

void CWSThreePosSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, CautionWarningSystem *c)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	cws = c;
}

//
// Set caution and warning source (e.g. CSM/LEM or CM)
//

/*bool CWSSourceSwitch::CheckMouseClick(int event, int mx, int my)

{
	if (ToggleSwitch::CheckMouseClick(event, mx, my)) {
		if (cws) {
			if (IsUp()) {
				cws->SetSource(CWS_SOURCE_CSM);
			}
			else if (IsDown()) {
				cws->SetSource(CWS_SOURCE_CM);
			}
		}
		return true;
	}

	return false;
}*/

bool CWSSourceSwitch::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState, dontspring))
	{
		if (cws)
		{
			if (IsUp())
			{
				cws->SetSource(CWS_SOURCE_CSM);
			}
			else if (IsDown())
			{
				cws->SetSource(CWS_SOURCE_CM);
			}
		}
		return true;
	}
	return false;
}

//
// Switch that controls AGC input channels.
//

bool AGCIOSwitch::SwitchTo(int newState, bool dontspring)
{
	if (ToggleSwitch::SwitchTo(newState,dontspring)) {
		if (agc) {
			if (IsUp()) {
				agc->SetInputChannelBit(Channel, Bit, UpValue);
			}
			else if (IsDown()) {
				agc->SetInputChannelBit(Channel, Bit, !UpValue);
			}
		}
		return true;
	}
	return false;
}

//
// CMC Hold/Free/Auto mode.
//

bool CMCModeHoldFreeSwitch::SwitchTo(int newState, bool dontspring)
{
	if (AGCThreePoswitch::SwitchTo(newState,dontspring)) {
		if (agc) {
			bool Hold = false;
			bool Free = false;

			if (IsCenter()) {
				Hold = true;
			}
			else if (IsDown()) {
				Free = true;
			}

			agc->SetInputChannelBit(031, HoldFunction, Hold);
			agc->SetInputChannelBit(031, FreeFunction, Free);
		}
		return true;
	}

	return false;
}

//
// CMC Optics Mode Switch
//

void CMCOpticsZeroSwitch::DoDrawSwitch(SURFHANDLE DrawSurface)
{
	if (IsUp())
	{
		oapiBlt(DrawSurface, SwitchSurface, x, y, xOffset, yOffset, width, height, SURF_PREDEF_CK);
	}
	else
	{
		oapiBlt(DrawSurface, SwitchSurface, x, y, xOffset - width, yOffset, width, height, SURF_PREDEF_CK);
	}
}

//
// If we add more caution and warning system switches which use toggle-switch, they could be derived from a new
// class which has the generic init function to set the cws.
//

void CWSSourceSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, CautionWarningSystem *c)

{
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	cws = c;
}


void AGCSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, ApolloGuidance *c, int xoffset, int yoffset)

{
	ToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row, xoffset, yoffset);
	agc = c;
}

void AGCThreePoswitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, ApolloGuidance *c)

{
	ThreePosSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	agc = c;
}

void AGCGuardedToggleSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, SURFHANDLE bsurf, SwitchRow &row, ApolloGuidance *c)

{
	GuardedToggleSwitch::Init(xp, yp, w, h, surf, bsurf, row);
	agc = c;
}

bool AGCIOGuardedToggleSwitch::SwitchTo(int newState, bool dontspring)
{
	if (AGCGuardedToggleSwitch::SwitchTo(newState, dontspring)) {
		if (agc) {
			if (IsUp()) {
				agc->SetInputChannelBit(Channel, Bit, UpValue);
			}
			else if (IsDown()) {
				agc->SetInputChannelBit(Channel, Bit, !UpValue);
			}
		}
		return true;
	}
	return false;
}


//
// Handcontroller Switch
//

HandcontrollerSwitch::HandcontrollerSwitch() {

	x = 0;
	y = 0;
	width = 0;
	height = 0;
	state = 0;
	switchSurface = 0;
	borderSurface = 0;
	switchRow = 0;
}

HandcontrollerSwitch::~HandcontrollerSwitch() {
}

void HandcontrollerSwitch::Register(PanelSwitchScenarioHandler &scnh, char *n, bool hasyawaxis) {

	name = n;
	hasYawAxis =hasyawaxis;
	scnh.RegisterSwitch(this);
}

void HandcontrollerSwitch::Init(int xp, int yp, int w, int h, SURFHANDLE surf, 	SURFHANDLE bsurf, SwitchRow &row) {

	x = xp;
	y = yp;
	width = w;
	height = h;
	switchSurface = surf;
	borderSurface = bsurf;
	
	row.AddSwitch(this);
	switchRow = &row;

	if (!sclick.isValid()) {
		row.panelSwitches->soundlib->LoadSound(sclick, THUMBWHEEL_SOUND, INTERNAL_ONLY);
	}
}

int HandcontrollerSwitch::GetState() {

	return state;
}

bool HandcontrollerSwitch::CheckMouseClick(int event, int mx, int my) {

	int OldState = state;

	if (event == PANEL_MOUSE_LBDOWN) {
		//
		// Check whether it's actually in our switch region.
		//

		if (mx < x || my < y)
			return false;

		if (mx > (x + width) || my > (y + height))
			return false;

		//
		// Yes, so now we just need to check whether it's an on or
		// off click.
		//

		if (mx < (x + (width / 3.))) {
			if (my < (y + (height * 2. / 3.))) {
				state = 2;
				sclick.play();
			} else if (hasYawAxis) {
				state = 5;
				sclick.play();
			}
		} else if (mx > (x + (width * 2. / 3.))) {
			if (my < (y + (height * 2. / 3.))) {
				state = 1;
				sclick.play();
			} else if (hasYawAxis) {
				state = 6;
				sclick.play();
			}
		} else {
			if (my < (y + (height / 2.))) {
				state = 4;
				sclick.play();
			} else {
				state = 3;
				sclick.play();
			}
		}
	} else if (event == PANEL_MOUSE_LBUP) {
		state = 0;
		sclick.play();
	}
	return true;
}

void HandcontrollerSwitch::DrawSwitch(SURFHANDLE DrawSurface) {

	if (!visible)
		return;

	oapiBlt(DrawSurface, switchSurface, x, y, state * width, 0, width, height, SURF_PREDEF_CK);
}

void HandcontrollerSwitch::DrawFlash(SURFHANDLE DrawSurface)

{
	if (!visible)
		return;

	if (borderSurface)
		oapiBlt(DrawSurface, borderSurface, x, y, 0, 0, width, height, SURF_PREDEF_CK);
}

void HandcontrollerSwitch::SaveState(FILEHANDLE scn) {

	oapiWriteScenario_int (scn, name, state);
}

void HandcontrollerSwitch::LoadState(char *line) {

	char buffer[100];
	int st;

	sscanf(line, "%s %i", buffer, &st); 
	if (!strnicmp(buffer, name, strlen(name))) {
		state = st;
	}
}

//
// Panel interface connector. This is here as it's primarily concerned
// with handling panel calls.
//

PanelConnector::PanelConnector(PanelSwitches &p, ChecklistController &c) : panel(p), checklist(c)

{
	type = MFD_PANEL_INTERFACE;
}

PanelConnector::~PanelConnector()

{
}

bool PanelConnector::ReceiveMessage(Connector *from, ConnectorMessage &m)

{
	//
	// Sanity check.
	//

	if (m.destination != type)
	{
		return false;
	}

	PanelConnectorMessageType messageType;

	messageType = (PanelConnectorMessageType) m.messageType;

	switch (messageType)
	{
	case MFD_PANEL_FLASH_ITEM:
		m.val1.bValue = panel.SetFlashing(static_cast<char *>(m.val1.pValue), m.val2.bValue);
		return true;

	case MFD_PANEL_GET_ITEM_STATE:
		m.val1.iValue = panel.GetState(static_cast<char *>(m.val1.pValue));
		return true;

	case MFD_PANEL_GET_ITEM_FLASHING:
		m.val1.bValue = panel.GetFlashing(static_cast<char *>(m.val1.pValue));
		return true;

	case MFD_PANEL_SET_ITEM_STATE:
		m.val1.bValue = panel.SetState(static_cast<char *>(m.val1.pValue), m.val2.iValue, m.val3.bValue, m.val4.bValue);
		return true;

	case MFD_PANEL_GET_FAILED_STATE:
		m.val1.bValue = panel.GetFailedState(static_cast<char *>(m.val1.pValue));
		return true;

	case MFD_PANEL_CHECKLIST_AUTOCOMPLETE:
		m.val1.bValue = checklist.autoComplete(m.val1.bValue);
		return true;
	case MFD_PANEL_GET_CHECKLIST_ITEM:
		m.val1.pValue = checklist.getChecklistItem(m.val1.iValue, m.val2.iValue);
		return true;
	case MFD_PANEL_GET_CHECKLIST_LIST:
		m.val1.pValue = checklist.getChecklistList();
		return true;
	case MFD_PANEL_FAIL_ITEM:
		m.val2.bValue = checklist.failChecklistItem(static_cast<ChecklistItem *>(m.val1.pValue));
		return true;
	case MFD_PANEL_COMPLETE_ITEM:
		m.val2.bValue = checklist.completeChecklistItem(static_cast<ChecklistItem *>(m.val1.pValue));
		return true;
	case MFD_PANEL_CHECKLIST_AUTOCOMPLETE_QUERY:
		m.val1.bValue = checklist.autoComplete();
		return true;
	case MFD_PANEL_CHECKLIST_NAME:
		m.val1.pValue = checklist.activeName();
		return true;
	case MFD_PANEL_RETRIEVE_CHECKLIST:
		m.val2.bValue = checklist.retrieveChecklistContainer(static_cast<ChecklistContainer *>(m.val1.pValue));
		return true;
	case MFD_PANEL_CHECKLIST_FLASHING_QUERY:
		m.val1.bValue = checklist.getFlashing();
		return true;
	case MFD_PANEL_CHECKLIST_FLASHING:
		checklist.setFlashing(m.val1.bValue);
		return true;
	case MFD_PANEL_GET_CHECKLIST_AUTOEXECUTE:
		m.val1.bValue = checklist.autoExecute();
		return true;
	case MFD_PANEL_SET_CHECKLIST_AUTOEXECUTE:
		checklist.autoExecute(m.val1.bValue);
		return true;
	case MFD_PANEL_GOTO_CHECKLIST_ITEM:
		m.val2.bValue = checklist.gotoChecklistItem(static_cast<ChecklistItem*>(m.val1.pValue));
		return true;
	case MFD_PANEL_UNDO_CHECKLIST_ITEM:
		m.val1.bValue = checklist.undoChecklistItem();
		return true;
	}

	return false;
}

void MasterAlarmSwitch::SetState(int value) {

	if (value == TOGGLESWITCH_UP)
		cws->PushMasterAlarm();
}

int MasterAlarmSwitch::GetState() {

	if (cws->GetMasterAlarm()) {
		return TOGGLESWITCH_DOWN;
	}
	return TOGGLESWITCH_UP;
}


void DSKYPushSwitch::DoDrawSwitch(SURFHANDLE DrawSurface) {

	if (IsUp())	{
		oapiBlt(DrawSurface, SwitchSurface, x, y, xOffset, yOffset, width, height, SURF_PREDEF_CK);
	} else {
		oapiBlt(DrawSurface, SwitchSurface, x, y, xOffset, yOffset + 120, width, height, SURF_PREDEF_CK);
	}
}

RotVariableVoltageTransformer::RotVariableVoltageTransformer(char* i_name, double MinVolt, double MaxVolt, bool DCAC) : VariableVoltageTransformer(i_name, MinVolt, MaxVolt, DCAC)
{
	rotary = NULL;
}

void RotVariableVoltageTransformer::Init(ContinuousSwitch* rot)
{
	rotary = rot;
}

double RotVariableVoltageTransformer::GetValue()
{
	if (rotary) return rotary->GetOutput();
	else return 0.0;
}

RotVoltageTransformerOverride::RotVoltageTransformerOverride(char* i_name, double MinVolt, double MaxVolt, bool DCAC) : RotVariableVoltageTransformer(i_name, MinVolt, MaxVolt, DCAC)
{
	OverrideSwitch = NULL;
}

void RotVoltageTransformerOverride::Init(ContinuousSwitch* rot, ToggleSwitch* ovrdsw)
{
	RotVariableVoltageTransformer::Init(rot);

	OverrideSwitch = ovrdsw;
}

void RotVoltageTransformerOverride::UpdateFlow(double dt)
{
	if (SRC)
	{
		// If override switch is up, pass through input voltage without change. Otherwise use rotational switch control.
		if (OverrideSwitch->IsUp())
		{
			Volts = SRC->Voltage();
		}
		else
		{
			double DesVolts = min_output_voltage + (max_output_voltage - min_output_voltage) * GetValue();
			Volts = min(SRC->Voltage(), DesVolts);
		}
	}
	else
	{
		Volts = 0.0;
	}

	if (Volts > 0.0) {
		Amperes = (power_load / Volts);
	}

	last_power_load = power_load;
	power_load = 0.0;
}

PanelGroup::~PanelGroup()
{
	while (!panels.empty()) {
		BasicPanel* panel = panels.back();
		if (panel) delete panel;
		panels.pop_back();
	}
}

bool PanelGroup::AddPanel(BasicPanel* pPanel, PanelSwitchScenarioHandler *PSH)
{
	panels.push_back(pPanel);
	pPanel->Register(PSH);
	return true;
}

VCPointingArrow::VCPointingArrow()
{
	first = true;
	arrow_group = NULL;
	arrowVertsCnt = circleVertsCnt = 0;
	arrowData = NULL;
	circle_group = NULL;
	circleData = NULL;
	circleDataOrig = NULL;
	rotationangle = rad = cos_a = sin_a = 0.0;
	camPosGlobal = camPos = camDir = globVesselPos = camPointing = _V(0, 0, 0);
	arrowCurPos = circleCurPos = _V(0, 0, 0);
	pointing_dir = _V(0, 0, 0);
	rot_axis = circle_dir = rot_axis_circle = final_vertex = _V(0, 0, 0);
	dot = angle = 0.0;
	rotation = rotation_circle = _M(0, 0, 0, 0, 0, 0, 0, 0, 0);
	dot_circle = angle_circle = 0.0;

	memset(&arrow_grp, 0, sizeof(GROUPREQUESTSPEC));
	memset(&circle_grp, 0, sizeof(GROUPREQUESTSPEC));

	vessel = NULL;
}

VCPointingArrow::~VCPointingArrow()
{
	if (arrowData) delete[] arrowData;
	if (circleData) delete[] circleData;
	if (circleDataOrig) delete[] circleDataOrig;
	if (arrow_grp.Vtx) delete[] arrow_grp.Vtx;
	if (circle_grp.Vtx) delete[] circle_grp.Vtx;
}

void VCPointingArrow::Init(VESSEL* v)
{
	vessel = v;
}

void VCPointingArrow::Timestep(int PointingArrowidx, DEVMESHHANDLE hArrowMesh, const VECTOR3& ofs, const VECTOR3& activeSwitchPos)
{
	oapiCameraGlobalPos(&camPosGlobal);							// Get camera (in global co-ords)
	vessel->Global2Local(camPosGlobal, camPos);					// Translate from global to local co-ordinates.
	oapiCameraGlobalDir(&camDir);								// Get camera direction (in global co-ords)
	vessel->GetGlobalPos(globVesselPos);						// Get global position of vessel so we can translate
	vessel->Global2Local(globVesselPos + camDir, camPointing);	// Translate from global to local co-ordinates.
	//	normalise(camPointing);

	if (first) {											// Run this once for retrieving the Arrow data
		arrow_group = oapiMeshGroup(vessel->GetMeshTemplate(PointingArrowidx), 0);
		arrowVertsCnt = arrow_group->nVtx;
		arrowData = new VECTOR3[arrowVertsCnt];
		for (int i = 0; i < arrowVertsCnt; i++) {			// Make a copy of the Arrow data
			arrowData[i].x = (double)arrow_group->Vtx[i].x;
			arrowData[i].y = (double)arrow_group->Vtx[i].y;
			arrowData[i].z = (double)arrow_group->Vtx[i].z;
		}
		circle_group = oapiMeshGroup(vessel->GetMeshTemplate(PointingArrowidx), 1);
		circleVertsCnt = circle_group->nVtx;
		circleData = new VECTOR3[circleVertsCnt];
		circleDataOrig = new VECTOR3[circleVertsCnt];
		for (int i = 0; i < circleVertsCnt; i++) {			// Make a copy of the Circle data
			circleDataOrig[i].x = (double)circle_group->Vtx[i].x;
			circleDataOrig[i].y = (double)circle_group->Vtx[i].y;
			circleDataOrig[i].z = (double)circle_group->Vtx[i].z;
		}
		first = false;
	}

	if (!oapiGetPause()) {
		rotationangle += oapiGetSimStep() / oapiGetTimeAcceleration() * -90;  // Rotate 360� every 4 Second
		if (rotationangle > 360) rotationangle = 0;
		rad = rotationangle * PI / 180.0;
		cos_a = std::cos(rad);
		sin_a = std::sin(rad);

		//Rotate Circle
		for (int i = 0; i < circleVertsCnt; i++) {
			circleData[i].x = circleDataOrig[i].x * cos_a - circleDataOrig[i].y * sin_a;
			circleData[i].y = circleDataOrig[i].x * sin_a + circleDataOrig[i].y * cos_a;
			circleData[i].z = circleDataOrig[i].z;
		}

		/*		// Rotate Arrow
				for (int i = 0; i < arrowVertsCnt; i++) {
					arrowData[i].x = arrowData[i].x * cos_a - arrowData[i].y * sin_a;
					arrowData[i].y = arrowData[i].x * sin_a + arrowData[i].y * cos_a;
				}
		*/
	}

	arrow_grp.nVtx = arrowVertsCnt;
	if (!arrow_grp.Vtx) arrow_grp.Vtx = new NTVERTEX[arrow_grp.nVtx];
	if (oapiGetMeshGroup(hArrowMesh, 0, &arrow_grp) != 0) {	// problems
		delete[]arrow_grp.Vtx;
		arrow_grp.Vtx = 0;
	}
	//	NTVERTEX *Vtx = arrow_grp.Vtx;

	circle_grp.nVtx = circleVertsCnt;
	if (!circle_grp.Vtx) circle_grp.Vtx = new NTVERTEX[circle_grp.nVtx];
	if (oapiGetMeshGroup(hArrowMesh, 1, &circle_grp) != 0) {	// problems
		delete[]circle_grp.Vtx;
		circle_grp.Vtx = 0;
	}
	//	NTVERTEX *Vtx2 = circle_grp.Vtx;

	arrowCurPos = camPos - ofs + (camPointing * 0.15);			// Move the Arrow to this Position
	circleCurPos = activeSwitchPos;								// Move the Circle to this Position

	// Rotation calculation to align the Arrow
	const VECTOR3 init_dir = { 0, 0, 1 };							// Direction of the arrow (initially along the positive Z-axis)
	pointing_dir = activeSwitchPos - arrowCurPos;				// Target direction (vector from the target location to the viewing direction)
	normalise(pointing_dir);

	rot_axis = crossp(init_dir, pointing_dir);					// Rotation axis (cross product of the initial and target directions)
	normalise(rot_axis);

	dot = dotp(init_dir, pointing_dir);							// Rotation angle (angle between the initial and target direction)
	angle = std::acos(max(-1.0, min(1.0, dot)));				// Clamp to avoid NaN

	rotation = rotm(rot_axis, angle);

	// *** Do the same from above for the Circle ** //
	circle_dir = activeSwitchPos - (camPos - ofs);
	normalise(circle_dir);

	rot_axis_circle = crossp(init_dir, circle_dir);
	normalise(rot_axis_circle);

	dot_circle = dotp(init_dir, circle_dir);
	angle_circle = std::acos(max(-1.0, min(1.0, dot_circle)));

	rotation_circle = rotm(rot_axis_circle, angle_circle);

	for (int i = 0; i < arrowVertsCnt; i++) {
		// Rotate, Translate and Scale the Arrow(Scale depends on Camera FOV)
		final_vertex = mul(rotation, arrowData[i] * oapiCameraAperture()) + arrowCurPos;

		arrow_grp.Vtx[i].x = (float)final_vertex.x;		// Copy Transformed Arrow Vertices
		arrow_grp.Vtx[i].y = (float)final_vertex.y;
		arrow_grp.Vtx[i].z = (float)final_vertex.z;
	}

	for (int i = 0; i < circleVertsCnt; i++) {
		// Rotate and Translate the Circle
		final_vertex = mul(rotation_circle, circleData[i]) + circleCurPos;

		circle_grp.Vtx[i].x = (float)final_vertex.x;	// Copy Transformed Circle Vertices
		circle_grp.Vtx[i].y = (float)final_vertex.y;
		circle_grp.Vtx[i].z = (float)final_vertex.z;
	}

	// ** View in debug line the Camera Position, direction and the First Vertex of the Pointing Arrow **
	//	sprintf(oapiDebugString(), "%.3f  %.3f  %.3f ** %.3f  %.3f  %.3f ** %.3f  %.3f  %.3f", camPos.x, camPos.y, camPos.z, camPointing.x, camPointing.y, camPointing.z, arrow_grp.Vtx[0].x, arrow_grp.Vtx[0].y, arrow_grp.Vtx[0].z);

	ges.flags = GRPEDIT_VTXCRD;
	ges.nVtx = arrow_grp.nVtx;
	ges.Vtx = arrow_grp.Vtx;
	ges.vIdx = 0;
	oapiEditMeshGroup(hArrowMesh, 0, &ges);	// Move the Arrow

	ges.nVtx = circle_grp.nVtx;
	ges.Vtx = circle_grp.Vtx;
	oapiEditMeshGroup(hArrowMesh, 1, &ges);	// Move the Circle

	vessel->SetMeshVisibilityMode(PointingArrowidx, MESHVIS_VC);
}